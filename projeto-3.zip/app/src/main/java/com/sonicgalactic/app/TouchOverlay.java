package com.sonicgalactic.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import org.libsdl.app.SDLActivity;

import java.io.InputStream;

/**
 * Botao S (tecla S) ao lado do botao A do jogo. So captura o toque dentro do
 * proprio botao; o resto da tela passa direto para o jogo (botoes/menus do script).
 */
public class TouchOverlay extends View {
    // Ajuste aqui se o S nao ficar bem do lado do A do jogo:
    private static final float OFFSET_X = -50f; // unidades "s" a esquerda do A (negativo = esquerda)
    private static final float OFFSET_Y = 8f;   // unidades "s" para baixo
    private static final float SIZE = 32f;      // tamanho do botao em unidades "s"

    private final Paint paint = new Paint();
    private final Bitmap bS, bSh;
    private final float dp;
    private float s, cx, cy, r;
    private boolean pressed;
    private int pid = -1;
    private static final long HIDE_MS = 4000, TAP_MS = 400;
    private final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
    private long lastShow = 0; // comeca escondido; aparece ao tocar na tela
    private long downAt = 0;

    private static native boolean nativeTouchActive(); // o script do jogo esta lendo o touch = botoes dele ativos
    private boolean nativeOk = true;
    private boolean lastVis = false;

    private boolean visible() {
        if (pressed) return true;
        if (nativeOk) {
            try { return nativeTouchActive(); } catch (UnsatisfiedLinkError | Exception ex) { nativeOk = false; }
        }
        return android.os.SystemClock.uptimeMillis() - lastShow < HIDE_MS; // plano B: toque rapido
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            boolean v = visible();
            if (v != lastVis) { lastVis = v; invalidate(); }
            h.postDelayed(this, 120);
        }
    };

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); h.post(poll); }
    @Override protected void onDetachedFromWindow() { h.removeCallbacks(poll); super.onDetachedFromWindow(); }

    private void show() {
        lastShow = android.os.SystemClock.uptimeMillis();
        invalidate();
        h.postDelayed(this::invalidate, HIDE_MS + 60);
    }

    /** Chamado pela Activity para TODO toque na tela (sem consumir). Toque rapido = mostra o S. */
    public void noteTouch(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) downAt = android.os.SystemClock.uptimeMillis();
        else if (a == MotionEvent.ACTION_UP && android.os.SystemClock.uptimeMillis() - downAt < TAP_MS) show();
    }

    public TouchOverlay(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        paint.setFilterBitmap(false);
        paint.setAlpha(235);
        bS = load(c, "dpad3");
        bSh = load(c, "dpadhighlight3");
        setClickable(false);
    }

    private static Bitmap load(Context c, String name) {
        try (InputStream in = c.getAssets().open("touch/" + name + ".png")) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float f = getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("scale", 100) / 100f;
        s = Math.max(2f, Math.min(5f, Math.min(h / 110f, w / 230f))) * Math.max(1f, dp / 2.6f) * f;
        float m = 16 * dp;
        float ax = w - m - 96 * s, ay = h - m - 48 * s;
        float aCx = ax + 72 * s, aCy = ay + 24 * s; // centro do A
        cx = aCx + OFFSET_X * s;
        cy = aCy + OFFSET_Y * s;
        r = SIZE / 2f * s * 1.3f;
    }

    @Override
    protected void onDraw(Canvas c) {
        Bitmap b = pressed ? bSh : bS;
        if (b == null || !visible()) return; // some em cutscene (sem toques rapidos)
        float h = SIZE / 2f * s;
        c.drawBitmap(b, null, new RectF(cx - h, cy - h, cx + h, cy + h), paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked(), idx = e.getActionIndex();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            if (pid == -1 && Math.hypot(e.getX(idx) - cx, e.getY(idx) - cy) <= r) {
                pid = e.getPointerId(idx);
                pressed = true;
                show();
                SDLActivity.onNativeKeyDown(KeyEvent.KEYCODE_S);
                invalidate();
                return true;
            }
            return false; // nao e do S: deixa o jogo receber
        }
        if (pid == -1) return false;
        boolean release = a == MotionEvent.ACTION_CANCEL
                || ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP) && e.getPointerId(idx) == pid);
        if (release) {
            pid = -1;
            pressed = false;
            SDLActivity.onNativeKeyUp(KeyEvent.KEYCODE_S);
            show();
        }
        return true;
    }
}

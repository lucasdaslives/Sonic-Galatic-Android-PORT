#!/usr/bin/env bash
# Uso: repack32.sh <link do apk 64 bits fix4> <apk gerado pelo gradle (so armeabi-v7a)> <saida.apk>
# Pega o fix4 (Java, assets, resources, Data.hatch) e troca so as libs nativas por 32 bits.
set -euo pipefail
BASE_URL="$1"; BUILT="$2"; OUT="$3"
BT=$(ls -d "${ANDROID_HOME:-$ANDROID_SDK_ROOT}"/build-tools/* | sort -V | tail -1)
W=$(mktemp -d)
mkdir -p "$(dirname "$OUT")" "$W/b"

curl -L --fail --retry 3 -o "$W/base.apk" "$BASE_URL"
unzip -q "$W/base.apk" -d "$W/b"
unzip -q "$BUILT" 'lib/armeabi-v7a/*' -d "$W/n"
test -f "$W/n/lib/armeabi-v7a/libmain.so"  || { echo "libmain.so 32 bits nao foi gerada"; exit 1; }
test -f "$W/n/lib/armeabi-v7a/libSDL2.so"  || { echo "libSDL2.so 32 bits nao foi gerada"; exit 1; }

# libdata.so e so o Data.hatch renomeado (sem codigo): reaproveita do fix4
mkdir -p "$W/b/lib/armeabi-v7a"
mv "$W/b/lib/arm64-v8a/libdata.so" "$W/b/lib/armeabi-v7a/libdata.so"
cp "$W/n/lib/armeabi-v7a/libmain.so" "$W/n/lib/armeabi-v7a/libSDL2.so" "$W/b/lib/armeabi-v7a/"
rm -rf "$W/b/lib/arm64-v8a" "$W/b/META-INF"

# resources.arsc precisa ir sem compressao
( cd "$W/b" && zip -q -X -0 "$W/unsigned.apk" resources.arsc && zip -q -X -r "$W/unsigned.apk" . -x resources.arsc )
"$BT/zipalign" -f -p 4 "$W/unsigned.apk" "$W/aligned.apk"
"$BT/apksigner" sign --ks app/release.jks --ks-pass pass:sonic123 --ks-key-alias sonic --key-pass pass:sonic123 \
  --v1-signing-enabled true --v2-signing-enabled true --out "$OUT" "$W/aligned.apk"
"$BT/apksigner" verify "$OUT"
ls -la "$OUT"

# Patch da engine: liga o renderizador OpenGL ES (a engine so desenha 3D - Special Stage /
# Bonus Stage, modelos, chao 3D - com o renderizador GL; o SDL2 puro nao tem 3D nenhum).
# Funciona com duas geracoes da engine:
#   ANTIGA (v1.x, ex.: v1.3): ja tem suporte a GLES2 (shaders GLSL ES 1.00) -> so precisa do contexto ES.
#   NOVA (2025+, shaders com "#version 130"): GLES 3.0 + shaders convertidos com macros.
# Se a versao da engine nao bater com nenhuma, NAO aplica nada e o build segue com o SDL2
# (SG_GLES_OK = FALSE), em vez de quebrar o build.
set(SG_GLES_OK FALSE)
set(SG_GLES_LIB GLESv2)

function(sg_replace FILE_PATH ANCHOR REPLACEMENT)
    file(READ "${FILE_PATH}" SG_SRC)
    string(FIND "${SG_SRC}" "${ANCHOR}" SG_POS)
    if(SG_POS EQUAL -1)
        message(FATAL_ERROR "gles_patch: trecho nao encontrado em ${FILE_PATH}: ${ANCHOR}")
    endif()
    string(REPLACE "${ANCHOR}" "${REPLACEMENT}" SG_SRC "${SG_SRC}")
    file(WRITE "${FILE_PATH}" "${SG_SRC}")
endfunction()

set(GLDIR "${ENGINE_DIR}/source/Engine/Rendering/GL")
set(GFX_CPP "${ENGINE_DIR}/source/Engine/Graphics.cpp")
set(SG_PROFILE_LINE "SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);")

# ---- arquivos obrigatorios ----
foreach(f "${GLDIR}/Includes.h" "${GLDIR}/GLRenderer.cpp" "${GLDIR}/GLShader.cpp" "${GLDIR}/GLShaderBuilder.cpp" "${GFX_CPP}")
    if(NOT EXISTS "${f}")
        message(WARNING "gles_patch: arquivo ausente (${f}); OpenGL ES NAO ligado (fica o SDL2, sem 3D)")
        return()
    endif()
endforeach()

file(READ "${GLDIR}/Includes.h" SG_INC_SRC)
file(READ "${GLDIR}/GLRenderer.cpp" SG_GLR_SRC)
file(READ "${GLDIR}/GLShader.cpp" SG_GLS_SRC)
file(READ "${GLDIR}/GLShaderBuilder.cpp" SG_GLB_SRC)
file(READ "${GFX_CPP}" SG_GFX_SRC)

if(SG_GFX_SRC MATCHES "SG_GLES_BACKEND")
    # ja aplicado: so descobre o modo pra escolher a biblioteca
    if(SG_GLS_SRC MATCHES "SG_GLES_SHADER")
        set(SG_GLES_LIB GLESv3)
    endif()
    set(SG_GLES_OK TRUE)
    message(STATUS "gles_patch: ja aplicado")
    return()
endif()

# ---- modo ----
if(SG_GLS_SRC MATCHES "std::string versionString")
    set(SG_MODE NEW)
else()
    set(SG_MODE OLD)
endif()

# ---- verificacao previa (nada e alterado se algo faltar) ----
set(SG_MISSING "")
string(FIND "${SG_GLR_SRC}" "${SG_PROFILE_LINE}" SG_P)
if(SG_P EQUAL -1)
    string(APPEND SG_MISSING "[GLRenderer.cpp: linha do profile] ")
endif()
string(FIND "${SG_GFX_SRC}" "// Compiler-directed renderer" SG_P)
if(SG_P EQUAL -1)
    string(APPEND SG_MISSING "[Graphics.cpp: Compiler-directed renderer] ")
endif()
if(SG_MODE STREQUAL "OLD")
    string(FIND "${SG_INC_SRC}" "#elif ANDROID
#include <SDL_opengles2.h>" SG_P)
    if(SG_P EQUAL -1)
        string(APPEND SG_MISSING "[Includes.h: ramo ANDROID com SDL_opengles2.h] ")
    endif()
else()
    string(FIND "${SG_GLS_SRC}" "std::string versionString = \"#version 130\\n\";" SG_P)
    if(SG_P EQUAL -1)
        string(APPEND SG_MISSING "[GLShader.cpp: versionString 130] ")
    endif()
    string(FIND "${SG_GLS_SRC}" "shaderSources.push_back(StringUtils::Create(versionString));" SG_P)
    if(SG_P EQUAL -1)
        string(APPEND SG_MISSING "[GLShader.cpp: push_back da versao] ")
    endif()
    if(SG_INC_SRC MATCHES "#elif ANDROID\n#include <SDL_opengles2.h>")
        set(SG_INC_MODE A)
    elseif(SG_INC_SRC MATCHES "#else\n#include <GL/glew.h>")
        set(SG_INC_MODE B)
    else()
        string(APPEND SG_MISSING "[Includes.h sem trecho conhecido] ")
    endif()
endif()
if(NOT SG_MISSING STREQUAL "")
    message(WARNING "gles_patch: engine diferente (${SG_MODE}), OpenGL ES NAO ligado (fica o SDL2, sem 3D): ${SG_MISSING}")
    return()
endif()
message(STATUS "gles_patch: modo ${SG_MODE}")

# ---- 1) contexto OpenGL ES ----
if(SG_MODE STREQUAL "OLD")
    # GLES 2.0 (a engine antiga so usa a API do GLES2)
    sg_replace("${GLDIR}/GLRenderer.cpp" "${SG_PROFILE_LINE}"
        [=[#ifdef ANDROID
	/*SG_GLES_CONTEXT*/
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
#else
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);
#endif]=])
    # GLES2 nao tem glPointSize (o tamanho do ponto vai no shader): vira no-op
    sg_replace("${GLDIR}/Includes.h" "#elif ANDROID
#include <SDL_opengles2.h>" "#elif ANDROID
/*SG_GLES_PATCH*/
#include <SDL_opengles2.h>
#define glPointSize(sgSize) ((void)0)")
    # Shaders: no GLES2 o fragment shader PRECISA declarar a precisao do float, senao nao compila
    # (tela toda preta). A engine antiga so declara isso nos shaders de arquivo, nao nos gerados
    # pelo GLShaderBuilder; aqui prefixamos a precisao em todos os fragment shaders.
    file(READ "${GLDIR}/GLShader.cpp" SG_SRC)
    set(SG_PREC_CODE [=["#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"]=])
    set(SG_A1 "const char* fragmentShaderSourceStr = fragmentShaderSource.c_str();")
    string(FIND "${SG_SRC}" "${SG_A1}" SG_P)
    if(NOT SG_P EQUAL -1)
        string(REPLACE "${SG_A1}" "/*SG_GLES_FSPREC*/
	fragmentShaderSource = std::string(${SG_PREC_CODE}) + fragmentShaderSource;
	${SG_A1}" SG_SRC "${SG_SRC}")
    else()
        message(WARNING "gles_patch: GLShader(std::string, std::string) nao achado; precisao dos shaders gerados nao aplicada")
    endif()
    string(REPLACE [=[sourceFSMod[0] = "precision mediump float;\n";]=] "sourceFSMod[0] = ${SG_PREC_CODE};" SG_SRC "${SG_SRC}")
    file(WRITE "${GLDIR}/GLShader.cpp" "${SG_SRC}")
    set(SG_GLES_LIB GLESv2)
else()
    # GLES 3.0
    if(SG_INC_MODE STREQUAL "A")
        sg_replace("${GLDIR}/Includes.h" "#elif ANDROID
#include <SDL_opengles2.h>" "#elif ANDROID
/*SG_GLES_PATCH*/
#include <GLES3/gl3.h>
#include <GLES2/gl2ext.h>")
    else()
        sg_replace("${GLDIR}/Includes.h" "#else
#include <GL/glew.h>" "#elif ANDROID
/*SG_GLES_PATCH*/
#include <GLES3/gl3.h>
#include <GLES2/gl2ext.h>
#else
#include <GL/glew.h>")
    endif()
    sg_replace("${GLDIR}/GLRenderer.cpp" "${SG_PROFILE_LINE}"
        [=[#ifdef ANDROID
	/*SG_GLES_CONTEXT*/
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
#else
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);
#endif]=])
    # shaders: a engine usa GLSL 1.30 (attribute/varying/texture2D/gl_FragColor);
    # no GLES 3.0 usamos "#version 300 es" + macros de compatibilidade.
    sg_replace("${GLDIR}/GLShader.cpp"
        [=[std::string versionString = "#version 130\n";]=]
        [=[#ifdef ANDROID
		std::string versionString = "#version 300 es\n";
	#else
		std::string versionString = "#version 130\n";
	#endif]=])
    sg_replace("${GLDIR}/GLShader.cpp"
        "shaderSources.push_back(StringUtils::Create(versionString));"
        [=[shaderSources.push_back(StringUtils::Create(versionString));
#ifdef ANDROID
	/*SG_GLES_SHADER*/
	{
		bool sgVert = processed.SourceText != nullptr && strstr(processed.SourceText, "gl_Position") != nullptr;
		std::string sgCompat = "precision highp float;\nprecision highp int;\nprecision highp sampler2D;\n";
		sgCompat += "vec4 sg_tex(sampler2D s, vec2 c) { return texture(s, c); }\n#define texture2D sg_tex\n";
		if (sgVert) {
			sgCompat += "#define attribute in\n#define varying out\n";
		}
		else {
			sgCompat += "#define varying in\nout vec4 sg_FragColor;\n#define gl_FragColor sg_FragColor\n";
		}
		shaderSources.push_back(StringUtils::Create(sgCompat));
	}
#endif]=])
    file(READ "${GLDIR}/GLShader.cpp" SG_SRC)
    string(REPLACE "precision mediump float;" "precision highp float;" SG_SRC "${SG_SRC}")
    file(WRITE "${GLDIR}/GLShader.cpp" "${SG_SRC}")
    file(READ "${GLDIR}/GLShaderBuilder.cpp" SG_SRC)
    string(REPLACE "precision mediump float;" "precision highp float;" SG_SRC "${SG_SRC}")
    file(WRITE "${GLDIR}/GLShaderBuilder.cpp" "${SG_SRC}")
    set(SG_GLES_LIB GLESv3)
endif()

# ---- 2) escolha do renderizador: se existir files/sdl2renderer.txt (opcao do app) usa o SDL2 antigo ----
sg_replace("${GFX_CPP}" "// Compiler-directed renderer"
    [=[#ifdef ANDROID
	/*SG_GLES_BACKEND*/
	{
		const char* sgBase = SDL_AndroidGetInternalStoragePath();
		if (sgBase) {
			char sgPath[1024];
			snprintf(sgPath, sizeof(sgPath), "%s/sdl2renderer.txt", sgBase);
			FILE* sgFile = fopen(sgPath, "rb");
			if (sgFile) {
				fclose(sgFile);
				Graphics::Renderer = "sdl2";
				SDL2Renderer::SetGraphicsFunctions();
				return;
			}
		}
	}
#endif
	// Compiler-directed renderer]=])
set(SG_GLES_OK TRUE)
message(STATUS "gles_patch: aplicado (${SG_MODE})")

# Patch da engine: liga o renderizador OpenGL ES (a engine so desenha 3D - Special Stage /
# Bonus Stage, modelos, chao 3D - com o renderizador GL; o SDL2 puro nao tem 3D nenhum).
# Mexe em: GL/Includes.h, GL/GLRenderer.cpp, GL/GLShader.cpp, GL/GLShaderBuilder.cpp, Graphics.cpp
function(sg_patch FILE_PATH MARK)
    if(NOT EXISTS "${FILE_PATH}")
        message(FATAL_ERROR "gles_patch: ${FILE_PATH} nao encontrado")
    endif()
    file(READ "${FILE_PATH}" SG_SRC)
    if(SG_SRC MATCHES "${MARK}")
        set(SG_PATCHED_ALREADY TRUE PARENT_SCOPE)
    else()
        set(SG_PATCHED_ALREADY FALSE PARENT_SCOPE)
    endif()
endfunction()

function(sg_replace FILE_PATH ANCHOR REPLACEMENT)
    file(READ "${FILE_PATH}" SG_SRC)
    string(FIND "${SG_SRC}" "${ANCHOR}" SG_POS)
    if(SG_POS EQUAL -1)
        message(FATAL_ERROR "gles_patch: trecho nao encontrado em ${FILE_PATH}: ${ANCHOR}")
    endif()
    string(REPLACE "${ANCHOR}" "${REPLACEMENT}" SG_SRC "${SG_SRC}")
    file(WRITE "${FILE_PATH}" "${SG_SRC}")
endfunction()

set(GLDIR "${ENGINE_DIR}/source/Engine/Rendering/GL")
set(GFX_CPP "${ENGINE_DIR}/source/Engine/Graphics.cpp")

sg_patch("${GLDIR}/Includes.h" "SG_GLES_PATCH")
if(SG_PATCHED_ALREADY)
    message(STATUS "gles_patch: ja aplicado")
    return()
endif()

# 1) Headers GLES 3 no Android
sg_replace("${GLDIR}/Includes.h" "#elif ANDROID
#include <SDL_opengles2.h>" "#elif ANDROID
/*SG_GLES_PATCH*/
#include <GLES3/gl3.h>
#include <GLES2/gl2ext.h>")

# 2) Contexto OpenGL ES 3.0 (em vez de OpenGL compatibility)
sg_replace("${GLDIR}/GLRenderer.cpp"
    "SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);"
    [=[#ifdef ANDROID
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
#else
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);
#endif]=])

# 3) Shaders: a engine usa GLSL 1.30 (attribute/varying/texture2D/gl_FragColor);
#    no GLES 3.0 usamos "#version 300 es" + macros de compatibilidade.
sg_replace("${GLDIR}/GLShader.cpp"
    [=[std::string versionString = "#version 130\n";]=]
    [=[#ifdef ANDROID
		std::string versionString = "#version 300 es\n";
	#else
		std::string versionString = "#version 130\n";
	#endif]=])
sg_replace("${GLDIR}/GLShader.cpp"
    "shaderSources.push_back(StringUtils::Create(versionString));"
    [=[shaderSources.push_back(StringUtils::Create(versionString));
#ifdef ANDROID
	/*SG_GLES_SHADER*/
	{
		bool sgVert = processed.SourceText != nullptr && strstr(processed.SourceText, "gl_Position") != nullptr;
		std::string sgCompat = "precision highp float;\nprecision highp int;\nprecision highp sampler2D;\n";
		sgCompat += "vec4 sg_tex(sampler2D s, vec2 c) { return texture(s, c); }\n#define texture2D sg_tex\n";
		if (sgVert) {
			sgCompat += "#define attribute in\n#define varying out\n";
		}
		else {
			sgCompat += "#define varying in\nout vec4 sg_FragColor;\n#define gl_FragColor sg_FragColor\n";
		}
		shaderSources.push_back(StringUtils::Create(sgCompat));
	}
#endif]=])
# precisao: highp em vez de mediump (as paletas/indices precisam)
file(READ "${GLDIR}/GLShader.cpp" SG_SRC)
string(REPLACE "precision mediump float;" "precision highp float;" SG_SRC "${SG_SRC}")
file(WRITE "${GLDIR}/GLShader.cpp" "${SG_SRC}")
file(READ "${GLDIR}/GLShaderBuilder.cpp" SG_SRC)
string(REPLACE "precision mediump float;" "precision highp float;" SG_SRC "${SG_SRC}")
file(WRITE "${GLDIR}/GLShaderBuilder.cpp" "${SG_SRC}")

# 4) Escolha do renderizador: se existir files/sdl2renderer.txt (opcao do app) usa o SDL2 antigo
sg_replace("${GFX_CPP}" "// Compiler-directed renderer"
    [=[#ifdef ANDROID
	/*SG_GLES_BACKEND*/
	{
		const char* sgBase = SDL_AndroidGetInternalStoragePath();
		if (sgBase) {
			char sgPath[1024];
			snprintf(sgPath, sizeof(sgPath), "%s/sdl2renderer.txt", sgBase);
			FILE* sgFile = fopen(sgPath, "rb");
			if (sgFile) {
				fclose(sgFile);
				Graphics::Renderer = "sdl2";
				SDL2Renderer::SetGraphicsFunctions();
				return;
			}
		}
	}
#endif
	// Compiler-directed renderer]=])
message(STATUS "gles_patch: aplicado")

# Patch da engine (StandardLibrary.cpp): esconde os botoes de toque do proprio Data.hatch.
# Esses botoes (sprite "Mobile Buttons") sao desenhados pelo script Screen/GalacticHUD.hsl
# apenas quando Device.IsMobile e verdadeiro. Aqui, quando QUEM chama Device.IsMobile e o
# GalacticHUD, devolvemos "falso": o HUD nao desenha os botoes do jogo e so ficam os do app.
# Os outros scripts (ex.: WindowManager) continuam vendo Device.IsMobile = verdadeiro.
set(STDLIB_CPP "${ENGINE_DIR}/source/Engine/Bytecode/StandardLibrary.cpp")
if(NOT EXISTS "${STDLIB_CPP}")
    message(FATAL_ERROR "mobilehud_patch: StandardLibrary.cpp nao encontrado em ${STDLIB_CPP}")
endif()
file(READ "${STDLIB_CPP}" STDLIB_SRC)
if(STDLIB_SRC MATCHES "MOBILEHUD_PATCH")
    message(STATUS "mobilehud_patch: ja aplicado")
else()
    set(ANCHOR_I "bool isMobile = Application::IsMobile();")
    string(FIND "${STDLIB_SRC}" "${ANCHOR_I}" POS_I)
    if(POS_I EQUAL -1)
        message(FATAL_ERROR "mobilehud_patch: Device_IsMobile nao encontrado em StandardLibrary.cpp (versao da engine diferente). Avise para ajustar o patch.")
    endif()
    set(PATCH_I [=[bool isMobile = Application::IsMobile();
	/*MOBILEHUD_PATCH*/
	if (isMobile) {
		VMThread* sgThread = &ScriptManager::Threads[threadID];
		if (sgThread->FrameCount > 0) {
			CallFrame* sgFrame = &sgThread->Frames[sgThread->FrameCount - 1];
			const char* sgSrc = nullptr;
			if (sgFrame->Module && sgFrame->Module->SourceFilename) {
				sgSrc = sgFrame->Module->SourceFilename;
			}
			else if (sgFrame->Function && sgFrame->Function->Module) {
				sgSrc = sgFrame->Function->Module->SourceFilename;
			}
			if (sgSrc && strstr(sgSrc, "GalacticHUD")) {
				isMobile = false;
			}
		}
	}]=])
    string(REPLACE "${ANCHOR_I}" "${PATCH_I}" STDLIB_SRC "${STDLIB_SRC}")
    file(WRITE "${STDLIB_CPP}" "${STDLIB_SRC}")
    message(STATUS "mobilehud_patch: aplicado em StandardLibrary.cpp")
endif()

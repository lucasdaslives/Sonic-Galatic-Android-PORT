# Patch da engine (Scene.cpp):
#  - Modo "esticar" (padrao): a imagem do jogo preenche a tela inteira do celular,
#    sem barras pretas e sem cortar nada (a opcao fica em SetupActivity, que grava
#    files/screenmode.txt com 1 = esticar, 0 = manter proporcao 16:9).
#  - Modo "manter proporcao": views sem draw target (menu de pausa, level select...)
#    usam o mesmo enquadramento (fit 16:9, centralizado) do jogo.
set(SCENE_CPP "${ENGINE_DIR}/source/Engine/Scene.cpp")
if(NOT EXISTS "${SCENE_CPP}")
    message(FATAL_ERROR "fitview_patch: Scene.cpp nao encontrado em ${SCENE_CPP}")
endif()
file(READ "${SCENE_CPP}" SCENE_SRC)
if(SCENE_SRC MATCHES "FITVIEW_PATCH")
    message(STATUS "fitview_patch: ja aplicado")
else()
    set(ANCHOR_A "Scene::SetView(viewIndex);")
    set(ANCHOR_B "Scene::RenderView(viewIndex, true);")
    string(FIND "${SCENE_SRC}" "${ANCHOR_A}" POS_A)
    string(FIND "${SCENE_SRC}" "${ANCHOR_B}" POS_B)
    if(POS_A EQUAL -1 OR POS_B EQUAL -1)
        message(FATAL_ERROR "fitview_patch: trechos de Scene.cpp nao encontrados (versao da engine diferente). Avise para ajustar o patch.")
    endif()
    set(PATCH_A [=[Scene::SetView(viewIndex);
	/*FITVIEW_PATCH*/
	if (!useDrawTarget && SG_ScreenMode() != 1) {
		int fvW = 0, fvH = 0;
		SDL_GetWindowSize(Application::Window, &fvW, &fvH);
		float fvVW = currentView->Width, fvVH = currentView->Height;
		if (fvW > 0 && fvH > 0 && fvVW > 0.0f && fvVH > 0.0f) {
			float fvOW, fvOH;
			if ((float)fvW / fvVW < (float)fvH / fvVH) {
				fvOW = (float)fvW;
				fvOH = (float)fvW * fvVH / fvVW;
			}
			else {
				fvOH = (float)fvH;
				fvOW = (float)fvH * fvVW / fvVH;
			}
			Graphics::SetViewport(((float)fvW - fvOW) * 0.5f, ((float)fvH - fvOH) * 0.5f, fvOW, fvOH);
		}
	}]=])
    set(PATCH_B [=[Scene::RenderView(viewIndex, true);
		/*FITVIEW_PATCH_B*/
		if (!(currentView->UseDrawTarget && currentView->DrawTarget)) {
			Graphics::ResetViewport();
		}]=])
    string(REPLACE "${ANCHOR_A}" "${PATCH_A}" SCENE_SRC "${SCENE_SRC}")
    string(REPLACE "${ANCHOR_B}" "${PATCH_B}" SCENE_SRC "${SCENE_SRC}")

    # Helper que le o modo de tela gravado pelo app (1 = esticar, 0 = manter proporcao)
    set(ANCHOR_H "#include <Engine/Utilities/StringUtils.h>")
    string(FIND "${SCENE_SRC}" "${ANCHOR_H}" POS_H)
    if(POS_H EQUAL -1)
        message(FATAL_ERROR "fitview_patch: include de StringUtils.h nao encontrado em Scene.cpp. Avise para ajustar o patch.")
    endif()
    set(PATCH_H [=[#include <Engine/Utilities/StringUtils.h>

/*FITVIEW_PATCH_H*/
static int SG_ScreenMode() {
	static int sgMode = -1;
	static Uint32 sgLast = 0;
	Uint32 sgNow = SDL_GetTicks();
	if (sgMode < 0 || sgNow - sgLast > 1000) {
		sgLast = sgNow;
		sgMode = 2;
#ifdef ANDROID
		const char* sgBase = SDL_AndroidGetInternalStoragePath();
		if (sgBase) {
			char sgPath[1024];
			snprintf(sgPath, sizeof(sgPath), "%s/screenmode.txt", sgBase);
			FILE* sgFile = fopen(sgPath, "rb");
			if (sgFile) {
				int sgCh = fgetc(sgFile);
				fclose(sgFile);
				if (sgCh == '0' || sgCh == '1' || sgCh == '2') {
					sgMode = sgCh - '0';
				}
			}
		}
#endif
	}
	return sgMode;
}
static bool SG_StretchScreen() {
	return SG_ScreenMode() == 1;
}

/*FITVIEW_PATCH_UI*/
static bool SG_NameHas(const char* name, const char* part) {
	return name != nullptr && strstr(name, part) != nullptr;
}

static bool SG_CutsceneNow() {
	// 1) cenas que sao inteiras de cutscene / splash / creditos
	char sgScene[512];
	snprintf(sgScene, sizeof(sgScene), "%s", Scene::CurrentScene);
	for (char* c = sgScene; *c; c++) {
		if (*c >= 'A' && *c <= 'Z') {
			*c = *c - 'A' + 'a';
		}
	}
	if (strstr(sgScene, "intro") || strstr(sgScene, "credits") || strstr(sgScene, "ending") ||
		strstr(sgScene, "sega") || strstr(sgScene, "starteam") || strstr(sgScene, "pleasesupport")) {
		return true;
	}
	// 2) cutscenes dentro da fase: algum objeto "Cutscene/Intro/Outro" ativo
	bool sgHit = false;
	if (Scene::ObjectLists) {
		Scene::ObjectLists->WithAll([&sgHit](Uint32, ObjectList* list) -> void {
			if (sgHit || list == nullptr || list->EntityCount <= 0) {
				return;
			}
			if (!(SG_NameHas(list->ObjectName, "Cutscene") || SG_NameHas(list->ObjectName, "Intro") ||
				    SG_NameHas(list->ObjectName, "Outro"))) {
				return;
			}
			for (Entity* e = list->EntityFirst; e != nullptr; e = e->NextEntityInList) {
				if (e->Active) {
					sgHit = true;
					return;
				}
			}
		});
	}
	return sgHit;
}

// Grava files/uistate.txt ("1" = esconder controles de toque, "0" = mostrar).
// So muda depois de ~0,4 s no mesmo estado, pra nao piscar.
static void SG_UpdateUiState() {
#ifdef ANDROID
	static Uint32 sgLastCheck = 0;
	static int sgWritten = -1;
	static int sgCandidate = 0;
	static Uint32 sgSince = 0;
	Uint32 sgNow = SDL_GetTicks();
	if (sgNow - sgLastCheck < 120) {
		return;
	}
	sgLastCheck = sgNow;
	int sgState = SG_CutsceneNow() ? 1 : 0;
	if (sgState != sgCandidate) {
		sgCandidate = sgState;
		sgSince = sgNow;
	}
	if (sgCandidate != sgWritten && (sgNow - sgSince >= 400 || sgWritten < 0)) {
		const char* sgBase = SDL_AndroidGetInternalStoragePath();
		if (sgBase) {
			char sgPath[1024];
			snprintf(sgPath, sizeof(sgPath), "%s/uistate.txt", sgBase);
			FILE* sgFile = fopen(sgPath, "wb");
			if (sgFile) {
				fputc(sgCandidate ? '1' : '0', sgFile);
				fclose(sgFile);
				sgWritten = sgCandidate;
			}
		}
	}
#endif
}]=])
    string(REPLACE "${ANCHOR_H}" "${PATCH_H}" SCENE_SRC "${SCENE_SRC}")

    # Aviso de cutscene pro app (esconde os controles de toque)
    set(ANCHOR_R "void Scene::Render() {")
    string(FIND "${SCENE_SRC}" "${ANCHOR_R}" POS_R)
    if(POS_R EQUAL -1)
        message(WARNING "fitview_patch: Scene::Render nao encontrado; esconder controles na cutscene nao aplicado")
    else()
        string(REPLACE "${ANCHOR_R}" "void Scene::Render() {\n\tSG_UpdateUiState(); /*FITVIEW_PATCH_R*/" SCENE_SRC "${SCENE_SRC}")
    endif()

    # Modo 2: repete as colunas/linhas da borda da imagem onde sobraria barra preta
    set(ANCHOR_E "Graphics::SetUserShader(shader);")
    string(FIND "${SCENE_SRC}" "${ANCHOR_E}" POS_E)
    if(POS_E EQUAL -1)
        message(WARNING "fitview_patch: SetUserShader(shader) nao encontrado; extensao de borda nao aplicada")
    else()
        set(PATCH_E [=[Graphics::SetUserShader(shader);
				/*FITVIEW_PATCH_E*/
				if (viewCount == 1 && SG_ScreenMode() == 2) {
					float sgBarW = out_x, sgBarH = out_y;
					if (sgBarW > 0.5f) {
						Graphics::DrawTexture(currentView->DrawTarget, 0.0, 0.0, 1.0, currentView->Height,
							0.0, out_y + Graphics::PixelOffset, sgBarW + 1.0f, out_h + Graphics::PixelOffset);
						Graphics::DrawTexture(currentView->DrawTarget, currentView->Width - 1.0, 0.0, 1.0, currentView->Height,
							out_x + out_w - 1.0f, out_y + Graphics::PixelOffset, (win_w - out_x - out_w) + 1.0f, out_h + Graphics::PixelOffset);
					}
					if (sgBarH > 0.5f) {
						Graphics::DrawTexture(currentView->DrawTarget, 0.0, 0.0, currentView->Width, 1.0,
							out_x, 0.0 + Graphics::PixelOffset, out_w, sgBarH + 1.0f + Graphics::PixelOffset);
						Graphics::DrawTexture(currentView->DrawTarget, 0.0, currentView->Height - 1.0, currentView->Width, 1.0,
							out_x, out_y + out_h - 1.0f + Graphics::PixelOffset, out_w, (win_h - out_y - out_h) + 1.0f + Graphics::PixelOffset);
					}
				}]=])
        string(REPLACE "${ANCHOR_E}" "${PATCH_E}" SCENE_SRC "${SCENE_SRC}")
    endif()

    # Render final: esticar a imagem do jogo na janela inteira
    set(ANCHOR_M "int aspectMode = (viewCount > 1) ? 3 : 1;")
    string(FIND "${SCENE_SRC}" "${ANCHOR_M}" POS_M)
    if(POS_M EQUAL -1)
        message(WARNING "fitview_patch: aspectMode nao encontrado; tela cheia (esticar) nao aplicada")
    else()
        set(PATCH_M "int aspectMode = (viewCount > 1) ? 3 : (SG_StretchScreen() ? 0 : 1); /*FITVIEW_PATCH_M*/")
        string(REPLACE "${ANCHOR_M}" "${PATCH_M}" SCENE_SRC "${SCENE_SRC}")
    endif()
    file(WRITE "${SCENE_CPP}" "${SCENE_SRC}")
    message(STATUS "fitview_patch: aplicado em Scene.cpp")
endif()

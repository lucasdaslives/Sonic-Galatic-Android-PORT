# Patch da engine (Scene.cpp):
#  - Modo "esticar" (padrao): a imagem do jogo preenche a tela inteira do celular,
#    sem barras pretas e sem cortar nada (a opcao fica em SetupActivity, que grava
#    files/screenmode.txt com 1 = esticar, 0 = manter proporcao 16:9).
#  - Modo "manter proporcao": views sem draw target (menu de pausa, level select...)
#    usam o mesmo enquadramento (fit 16:9, centralizado) do jogo.
set(SCENE_CPP "${ENGINE_DIR}/source/Engine/Scene.cpp")
if(NOT EXISTS "${SCENE_CPP}")
    message(FATAL_ERROR "fitview_patch: Scene.cpp nao encontrado em ${SCENE_CPP}")
endif()
file(READ "${SCENE_CPP}" SCENE_SRC)
if(SCENE_SRC MATCHES "FITVIEW_PATCH")
    message(STATUS "fitview_patch: ja aplicado")
else()
    set(ANCHOR_A "Scene::SetView(viewIndex);")
    set(ANCHOR_B "Scene::RenderView(viewIndex, true);")
    string(FIND "${SCENE_SRC}" "${ANCHOR_A}" POS_A)
    string(FIND "${SCENE_SRC}" "${ANCHOR_B}" POS_B)
    if(POS_A EQUAL -1 OR POS_B EQUAL -1)
        message(FATAL_ERROR "fitview_patch: trechos de Scene.cpp nao encontrados (versao da engine diferente). Avise para ajustar o patch.")
    endif()
    set(PATCH_A [=[Scene::SetView(viewIndex);
	/*FITVIEW_PATCH*/
	if (!useDrawTarget && SG_ScreenMode() != 1) {
		int fvW = 0, fvH = 0;
		SDL_GetWindowSize(Application::Window, &fvW, &fvH);
		float fvVW = currentView->Width, fvVH = currentView->Height;
		if (fvW > 0 && fvH > 0 && fvVW > 0.0f && fvVH > 0.0f) {
			float fvOW, fvOH;
			if ((float)fvW / fvVW < (float)fvH / fvVH) {
				fvOW = (float)fvW;
				fvOH = (float)fvW * fvVH / fvVW;
			}
			else {
				fvOH = (float)fvH;
				fvOW = (float)fvH * fvVW / fvVH;
			}
			Graphics::SetViewport(((float)fvW - fvOW) * 0.5f, ((float)fvH - fvOH) * 0.5f, fvOW, fvOH);
		}
	}]=])
    set(PATCH_B [=[Scene::RenderView(viewIndex, true);
		/*FITVIEW_PATCH_B*/
		if (!(currentView->UseDrawTarget && currentView->DrawTarget)) {
			Graphics::ResetViewport();
		}]=])
    string(REPLACE "${ANCHOR_A}" "${PATCH_A}" SCENE_SRC "${SCENE_SRC}")
    string(REPLACE "${ANCHOR_B}" "${PATCH_B}" SCENE_SRC "${SCENE_SRC}")

    # Helper que le o modo de tela gravado pelo app (1 = esticar, 0 = manter proporcao)
    set(ANCHOR_H "#include <Engine/Utilities/StringUtils.h>")
    string(FIND "${SCENE_SRC}" "${ANCHOR_H}" POS_H)
    if(POS_H EQUAL -1)
        message(FATAL_ERROR "fitview_patch: include de StringUtils.h nao encontrado em Scene.cpp. Avise para ajustar o patch.")
    endif()
    set(PATCH_H [=[#include <Engine/Utilities/StringUtils.h>

/*FITVIEW_PATCH_H*/
static int SG_ScreenMode() {
	static int sgMode = -1;
	static Uint32 sgLast = 0;
	Uint32 sgNow = SDL_GetTicks();
	if (sgMode < 0 || sgNow - sgLast > 1000) {
		sgLast = sgNow;
		sgMode = 2;
#ifdef ANDROID
		const char* sgBase = SDL_AndroidGetInternalStoragePath();
		if (sgBase) {
			char sgPath[1024];
			snprintf(sgPath, sizeof(sgPath), "%s/screenmode.txt", sgBase);
			FILE* sgFile = fopen(sgPath, "rb");
			if (sgFile) {
				int sgCh = fgetc(sgFile);
				fclose(sgFile);
				if (sgCh == '0' || sgCh == '1' || sgCh == '2') {
					sgMode = sgCh - '0';
				}
			}
		}
#endif
	}
	return sgMode;
}
static bool SG_StretchScreen() {
	return SG_ScreenMode() == 1;
}

/*FITVIEW_PATCH_UI*/
static void SG_Lower(const char* in, char* out, size_t n) {
	size_t i = 0;
	if (in != nullptr) {
		for (; in[i] && i + 1 < n; i++) {
			char c = in[i];
			out[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
		}
	}
	out[i] = 0;
}

static bool SG_NameHas(const char* name, const char* part) {
	char n[160];
	SG_Lower(name, n, sizeof(n));
	return strstr(n, part) != nullptr;
}

// Compila mesmo que a Entity nao tenha o campo "Visible" (ai simplesmente nao faz nada)
template <typename T> static auto SG_SetInvisibleImpl(T* e, int) -> decltype((void)(e->Visible = false)) { e->Visible = false; }
template <typename T> static void SG_SetInvisibleImpl(T*, long) { }

// Le Scene::Frame se a engine tiver esse campo (senao devolve -1 e so vale a troca de nome da cena)
template <typename T> static auto SG_FrameImpl(int) -> decltype((void)T::Frame, int()) { return (int)T::Frame; }
template <typename T> static int SG_FrameImpl(long) { return -1; }

// Retorna: 4 = menu (botao voltar), 0 = jogo (botoes visiveis), 1 = cutscene (segurar = Start),
// 2 = Sega/Starteam/title (tocar = A+Start), 3 = fim de fase / act clear (botoes somem)
static int SG_TM_PausedNow(); // definida no bloco touchmenu (mais abaixo)
static int SG_UiStateNow() {
	// Special Stage / Bonus Stage (objeto SSGem): sempre jogo normal, botoes visiveis
	if (Scene::ObjectLists) {
		bool sgSS = false;
		Scene::ObjectLists->WithAll([&sgSS](Uint32, ObjectList* list) -> void {
			if (list != nullptr && list->EntityCount > 0 &&
				(SG_NameHas(list->ObjectName, "ssgem") || SG_NameHas(list->ObjectName, "specialstage") ||
				 SG_NameHas(list->ObjectName, "bonusstage"))) {
				sgSS = true;
			}
		});
		if (sgSS) {
			return 0;
		}
	}
	char sgScene[512];
	SG_Lower(Scene::CurrentScene, sgScene, sizeof(sgScene));
	if (strstr(sgScene, "sega") || strstr(sgScene, "starteam") || strstr(sgScene, "pleasesupport") ||
		strstr(sgScene, "title")) {
		return 2;
	}
	if (strstr(sgScene, "intro") || strstr(sgScene, "credits") || strstr(sgScene, "ending")) {
		return 1;
	}
	if (strstr(sgScene, "menus/")) {
		return 4; // menu (nao e jogo nem pausa): o app mostra o botao de voltar
	}
	if (SG_TM_PausedNow()) {
		return 5; // menu de pausa aberto (PauseManager.RenderMenu): botoes do app somem
	}
	bool sgCut = false, sgClear = false;
	if (Scene::ObjectLists) {
		Scene::ObjectLists->WithAll([&sgCut, &sgClear](Uint32, ObjectList* list) -> void {
			if (list == nullptr || list->EntityCount <= 0) {
				return;
			}
			bool isCut = SG_NameHas(list->ObjectName, "cutscene") || SG_NameHas(list->ObjectName, "intro") ||
				SG_NameHas(list->ObjectName, "outro");
			bool isClear = SG_NameHas(list->ObjectName, "actclear") || SG_NameHas(list->ObjectName, "levelclear") ||
				SG_NameHas(list->ObjectName, "stageclear") || SG_NameHas(list->ObjectName, "actfinish") ||
				SG_NameHas(list->ObjectName, "result") || SG_NameHas(list->ObjectName, "tally");
			if (!isCut && !isClear) {
				return;
			}
			for (Entity* e = list->EntityFirst; e != nullptr; e = e->NextEntityInList) {
				if (e->Active) {
					if (isCut) sgCut = true;
					if (isClear) sgClear = true;
					return;
				}
			}
		});
	}
	// Act clear "grudado": so vale se o ActClear ficou ativo DEPOIS de a cena carregar (borda de subida),
	// e no maximo 30 s. Assim, ao comecar uma act nova, os botoes voltam mesmo se sobrar algum objeto de resultado ativo.
	static char sgPrevScene[512] = "";
	static bool sgClearIgnore = false;
	static Uint32 sgClearStart = 0;
	static int sgPrevFrame = -1;
	int sgFrame = SG_FrameImpl<Scene>(0);
	bool sgReloaded = sgFrame >= 0 && sgPrevFrame >= 0 && sgFrame < sgPrevFrame;
	sgPrevFrame = sgFrame;
	if (sgReloaded || strcmp(sgPrevScene, sgScene) != 0) {
		snprintf(sgPrevScene, sizeof(sgPrevScene), "%s", sgScene);
		sgClearIgnore = sgClear;
		sgClearStart = 0;
	}
	if (!sgClear) {
		sgClearIgnore = false;
		sgClearStart = 0;
	}
	bool sgClearNow = sgClear && !sgClearIgnore;
	if (sgClearNow) {
		Uint32 sgT = SDL_GetTicks();
		if (sgClearStart == 0) {
			sgClearStart = sgT;
		}
		if (sgT - sgClearStart > 30000) {
			sgClearNow = false;
		}
	}
	return sgCut ? 1 : (sgClearNow ? 3 : 0);
}

// Esconde os botoes de toque desenhados pelo jogo (Data.hatch): so ficam os do app
static void SG_HideEngineTouch() {
#ifdef ANDROID
	if (!Scene::ObjectLists) {
		return;
	}
	Scene::ObjectLists->WithAll([](Uint32, ObjectList* list) -> void {
		if (list == nullptr || list->EntityCount <= 0) {
			return;
		}
		if (!(SG_NameHas(list->ObjectName, "touch") || SG_NameHas(list->ObjectName, "dpad") ||
			  SG_NameHas(list->ObjectName, "virtual") || SG_NameHas(list->ObjectName, "onscreen") ||
			  SG_NameHas(list->ObjectName, "joystick") || SG_NameHas(list->ObjectName, "mobile"))) {
			return;
		}
		for (Entity* e = list->EntityFirst; e != nullptr; e = e->NextEntityInList) {
			SG_SetInvisibleImpl(e, 0);
			e->Active = false; // sem update e sem desenho: so ficam os botoes do app
		}
	});
#endif
}

// Diagnostico: a cada 3 s grava (pasta externa do app)/objects.txt com a cena e os objetos ativos
static void SG_DumpObjects() {
#ifdef ANDROID
	static Uint32 sgLastDump = 0;
	Uint32 sgNow = SDL_GetTicks();
	if (sgNow - sgLastDump < 3000) {
		return;
	}
	sgLastDump = sgNow;
	const char* sgBase = SDL_AndroidGetExternalStoragePath();
	if (!sgBase) {
		return;
	}
	char sgPath[1024];
	snprintf(sgPath, sizeof(sgPath), "%s/objects.txt", sgBase);
	FILE* sgFile = fopen(sgPath, "wb");
	if (!sgFile) {
		return;
	}
	fprintf(sgFile, "scene=%s\nuistate=%d\nobjetos com entidades:\n", Scene::CurrentScene, SG_UiStateNow());
	if (Scene::ObjectLists) {
		Scene::ObjectLists->WithAll([sgFile](Uint32, ObjectList* list) -> void {
			if (list != nullptr && list->EntityCount > 0 && list->ObjectName != nullptr) {
				fprintf(sgFile, "%s (%d)\n", list->ObjectName, (int)list->EntityCount);
			}
		});
	}
	fclose(sgFile);
#endif
}

// Grava files/uistate.txt ("0" = visiveis, "1" = cutscene, "2" = Sega/Starteam/title, "3" = fim de fase).
// So muda depois de ~0,4 s no mesmo estado, pra nao piscar.
static void SG_UpdateUiState() {
#ifdef ANDROID
	static Uint32 sgLastCheck = 0;
	static int sgWritten = -1;
	static int sgCandidate = 0;
	static Uint32 sgSince = 0;
	Uint32 sgNow = SDL_GetTicks();
	if (sgNow - sgLastCheck < 40) {
		return;
	}
	sgLastCheck = sgNow;
	int sgState = SG_UiStateNow();
	if (sgState != sgCandidate) {
		sgCandidate = sgState;
		sgSince = sgNow;
	}
	if (sgCandidate != sgWritten && (sgNow - sgSince >= 250 || sgWritten < 0 || (sgWritten == 3 && sgCandidate != 3))) {
		const char* sgBase = SDL_AndroidGetInternalStoragePath();
		if (sgBase) {
			char sgPath[1024];
			snprintf(sgPath, sizeof(sgPath), "%s/uistate.txt", sgBase);
			FILE* sgFile = fopen(sgPath, "wb");
			if (sgFile) {
				fputc('0' + sgCandidate, sgFile);
				fclose(sgFile);
				sgWritten = sgCandidate;
			}
		}
	}
#endif
}]=])
    string(REPLACE "${ANCHOR_H}" "${PATCH_H}" SCENE_SRC "${SCENE_SRC}")

    # Aviso de cutscene pro app (esconde os controles de toque)
    set(ANCHOR_R "void Scene::Render() {")
    string(FIND "${SCENE_SRC}" "${ANCHOR_R}" POS_R)
    if(POS_R EQUAL -1)
        message(WARNING "fitview_patch: Scene::Render nao encontrado; esconder controles na cutscene nao aplicado")
    else()
        string(REPLACE "${ANCHOR_R}" "void Scene::Render() {\n\tSG_UpdateUiState(); SG_HideEngineTouch(); SG_DumpObjects(); /*FITVIEW_PATCH_R*/" SCENE_SRC "${SCENE_SRC}")
    endif()

    # Modo 2: repete as colunas/linhas da borda da imagem onde sobraria barra preta
    set(ANCHOR_E "Graphics::SetUserShader(shader);")
    string(FIND "${SCENE_SRC}" "${ANCHOR_E}" POS_E)
    if(POS_E EQUAL -1)
        message(WARNING "fitview_patch: SetUserShader(shader) nao encontrado; extensao de borda nao aplicada")
    else()
        set(PATCH_E [=[Graphics::SetUserShader(shader);
				/*FITVIEW_PATCH_E*/
				if (viewCount == 1 && SG_ScreenMode() == 2) {
					float sgBarW = out_x, sgBarH = out_y;
					if (sgBarW > 0.5f) {
						Graphics::DrawTexture(currentView->DrawTarget, 0.0, 0.0, 1.0, currentView->Height,
							0.0, out_y + Graphics::PixelOffset, sgBarW + 1.0f, out_h + Graphics::PixelOffset);
						Graphics::DrawTexture(currentView->DrawTarget, currentView->Width - 1.0, 0.0, 1.0, currentView->Height,
							out_x + out_w - 1.0f, out_y + Graphics::PixelOffset, (win_w - out_x - out_w) + 1.0f, out_h + Graphics::PixelOffset);
					}
					if (sgBarH > 0.5f) {
						Graphics::DrawTexture(currentView->DrawTarget, 0.0, 0.0, currentView->Width, 1.0,
							out_x, 0.0 + Graphics::PixelOffset, out_w, sgBarH + 1.0f + Graphics::PixelOffset);
						Graphics::DrawTexture(currentView->DrawTarget, 0.0, currentView->Height - 1.0, currentView->Width, 1.0,
							out_x, out_y + out_h - 1.0f + Graphics::PixelOffset, out_w, (win_h - out_y - out_h) + 1.0f + Graphics::PixelOffset);
					}
				}]=])
        string(REPLACE "${ANCHOR_E}" "${PATCH_E}" SCENE_SRC "${SCENE_SRC}")

    endif()

    # Render final: esticar a imagem do jogo na janela inteira
    set(ANCHOR_M "int aspectMode = (viewCount > 1) ? 3 : 1;")
    string(FIND "${SCENE_SRC}" "${ANCHOR_M}" POS_M)
    if(POS_M EQUAL -1)
        message(WARNING "fitview_patch: aspectMode nao encontrado; tela cheia (esticar) nao aplicada")
    else()
        set(PATCH_M "int aspectMode = (viewCount > 1) ? 3 : (SG_StretchScreen() ? 0 : 1); /*FITVIEW_PATCH_M*/")
        string(REPLACE "${ANCHOR_M}" "${PATCH_M}" SCENE_SRC "${SCENE_SRC}")
    endif()
    file(WRITE "${SCENE_CPP}" "${SCENE_SRC}")
    message(STATUS "fitview_patch: aplicado em Scene.cpp")
endif()

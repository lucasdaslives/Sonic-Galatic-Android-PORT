# Patch da engine (Scene.cpp):
#  - Modo "esticar" (padrao): a imagem do jogo preenche a tela inteira do celular,
#    sem barras pretas e sem cortar nada (a opcao fica em SetupActivity, que grava
#    files/screenmode.txt com 1 = esticar, 0 = manter proporcao 16:9).
#  - Modo "manter proporcao": views sem draw target (menu de pausa, level select...)
#    usam o mesmo enquadramento (fit 16:9, centralizado) do jogo.
set(SCENE_CPP "${ENGINE_DIR}/source/Engine/Scene.cpp")
if(NOT EXISTS "${SCENE_CPP}")
    message(FATAL_ERROR "fitview_patch: Scene.cpp nao encontrado em ${SCENE_CPP}")
endif()
file(READ "${SCENE_CPP}" SCENE_SRC)
if(SCENE_SRC MATCHES "FITVIEW_PATCH")
    message(STATUS "fitview_patch: ja aplicado")
else()
    set(ANCHOR_A "Scene::SetView(viewIndex);")
    set(ANCHOR_B "Scene::RenderView(viewIndex, true);")
    string(FIND "${SCENE_SRC}" "${ANCHOR_A}" POS_A)
    string(FIND "${SCENE_SRC}" "${ANCHOR_B}" POS_B)
    if(POS_A EQUAL -1 OR POS_B EQUAL -1)
        message(FATAL_ERROR "fitview_patch: trechos de Scene.cpp nao encontrados (versao da engine diferente). Avise para ajustar o patch.")
    endif()
    set(PATCH_A [=[Scene::SetView(viewIndex);
	/*FITVIEW_PATCH*/
	if (!useDrawTarget && SG_ScreenMode() != 1) {
		int fvW = 0, fvH = 0;
		SDL_GetWindowSize(Application::Window, &fvW, &fvH);
		float fvVW = currentView->Width, fvVH = currentView->Height;
		if (fvW > 0 && fvH > 0 && fvVW > 0.0f && fvVH > 0.0f) {
			float fvOW, fvOH;
			if ((float)fvW / fvVW < (float)fvH / fvVH) {
				fvOW = (float)fvW;
				fvOH = (float)fvW * fvVH / fvVW;
			}
			else {
				fvOH = (float)fvH;
				fvOW = (float)fvH * fvVW / fvVH;
			}
			Graphics::SetViewport(((float)fvW - fvOW) * 0.5f, ((float)fvH - fvOH) * 0.5f, fvOW, fvOH);
		}
	}]=])
    set(PATCH_B [=[Scene::RenderView(viewIndex, true);
		/*FITVIEW_PATCH_B*/
		if (!(currentView->UseDrawTarget && currentView->DrawTarget)) {
			Graphics::ResetViewport();
		}]=])
    string(REPLACE "${ANCHOR_A}" "${PATCH_A}" SCENE_SRC "${SCENE_SRC}")
    string(REPLACE "${ANCHOR_B}" "${PATCH_B}" SCENE_SRC "${SCENE_SRC}")

    # Helper que le o modo de tela gravado pelo app (1 = esticar, 0 = manter proporcao)
    set(ANCHOR_H "#include <Engine/Utilities/StringUtils.h>")
    string(FIND "${SCENE_SRC}" "${ANCHOR_H}" POS_H)
    if(POS_H EQUAL -1)
        message(FATAL_ERROR "fitview_patch: include de StringUtils.h nao encontrado em Scene.cpp. Avise para ajustar o patch.")
    endif()
    set(PATCH_H [=[#include <Engine/Utilities/StringUtils.h>

/*FITVIEW_PATCH_H*/
static int SG_ScreenMode() {
	static int sgMode = -1;
	static Uint32 sgLast = 0;
	Uint32 sgNow = SDL_GetTicks();
	if (sgMode < 0 || sgNow - sgLast > 1000) {
		sgLast = sgNow;
		sgMode = 2;
#ifdef ANDROID
		const char* sgBase = SDL_AndroidGetInternalStoragePath();
		if (sgBase) {
			char sgPath[1024];
			snprintf(sgPath, sizeof(sgPath), "%s/screenmode.txt", sgBase);
			FILE* sgFile = fopen(sgPath, "rb");
			if (sgFile) {
				int sgCh = fgetc(sgFile);
				fclose(sgFile);
				if (sgCh == '0' || sgCh == '1' || sgCh == '2') {
					sgMode = sgCh - '0';
				}
			}
		}
#endif
	}
	return sgMode;
}
static bool SG_StretchScreen() {
	return SG_ScreenMode() == 1;
}

/*FITVIEW_PATCH_UI*/
static void SG_Lower(const char* in, char* out, size_t n) {
	size_t i = 0;
	if (in != nullptr) {
		for (; in[i] && i + 1 < n; i++) {
			char c = in[i];
			out[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
		}
	}
	out[i] = 0;
}

static bool SG_NameHas(const char* name, const char* part) {
	char n[160];
	SG_Lower(name, n, sizeof(n));
	return strstr(n, part) != nullptr;
}

// Menu principal: a parte da tela alem do 16:9 original vira o prolongamento esticado (ceu/chao)
static bool SG_MenuStretchNow() {
	if (SG_ScreenMode() == 1) {
		return false;
	}
	char sgScene[512];
	SG_Lower(Scene::CurrentScene, sgScene, sizeof(sgScene));
	return strstr(sgScene, "menu") != nullptr;
}

// Compila mesmo que a Entity nao tenha o campo "Visible" (ai simplesmente nao faz nada)
template <typename T> static auto SG_SetInvisibleImpl(T* e, int) -> decltype((void)(e->Visible = false)) { e->Visible = false; }
template <typename T> static void SG_SetInvisibleImpl(T*, long) { }

// Retorna: 0 = jogo/menu (botoes visiveis), 1 = cutscene (segurar = Start),
// 2 = Sega/Starteam/title (tocar = A+Start), 3 = fim de fase / act clear (botoes somem)
static int SG_UiStateNow() {
	char sgScene[512];
	SG_Lower(Scene::CurrentScene, sgScene, sizeof(sgScene));
	if (strstr(sgScene, "sega") || strstr(sgScene, "starteam") || strstr(sgScene, "pleasesupport") ||
		strstr(sgScene, "title")) {
		return 2;
	}
	if (strstr(sgScene, "intro") || strstr(sgScene, "credits") || strstr(sgScene, "ending")) {
		return 1;
	}
	bool sgCut = false, sgClear = false;
	if (Scene::ObjectLists) {
		Scene::ObjectLists->WithAll([&sgCut, &sgClear](Uint32, ObjectList* list) -> void {
			if (list == nullptr || list->EntityCount <= 0) {
				return;
			}
			bool isCut = SG_NameHas(list->ObjectName, "cutscene") || SG_NameHas(list->ObjectName, "intro") ||
				SG_NameHas(list->ObjectName, "outro");
			bool isClear = SG_NameHas(list->ObjectName, "actclear") || SG_NameHas(list->ObjectName, "levelclear") ||
				SG_NameHas(list->ObjectName, "stageclear") || SG_NameHas(list->ObjectName, "actfinish") ||
				SG_NameHas(list->ObjectName, "result") || SG_NameHas(list->ObjectName, "tally");
			if (!isCut && !isClear) {
				return;
			}
			for (Entity* e = list->EntityFirst; e != nullptr; e = e->NextEntityInList) {
				if (e->Active) {
					if (isCut) sgCut = true;
					if (isClear) sgClear = true;
					return;
				}
			}
		});
	}
	return sgCut ? 1 : (sgClear ? 3 : 0);
}

// Esconde os botoes de toque desenhados pelo jogo (Data.hatch): so ficam os do app
static void SG_HideEngineTouch() {
#ifdef ANDROID
	if (!Scene::ObjectLists) {
		return;
	}
	Scene::ObjectLists->WithAll([](Uint32, ObjectList* list) -> void {
		if (list == nullptr || list->EntityCount <= 0) {
			return;
		}
		if (!(SG_NameHas(list->ObjectName, "touch") || SG_NameHas(list->ObjectName, "dpad") ||
			  SG_NameHas(list->ObjectName, "virtualpad") || SG_NameHas(list->ObjectName, "onscreen"))) {
			return;
		}
		for (Entity* e = list->EntityFirst; e != nullptr; e = e->NextEntityInList) {
			SG_SetInvisibleImpl(e, 0);
		}
	});
#endif
}

// Diagnostico: a cada 3 s grava (pasta externa do app)/objects.txt com a cena e os objetos ativos
static void SG_DumpObjects() {
#ifdef ANDROID
	static Uint32 sgLastDump = 0;
	Uint32 sgNow = SDL_GetTicks();
	if (sgNow - sgLastDump < 3000) {
		return;
	}
	sgLastDump = sgNow;
	const char* sgBase = SDL_AndroidGetExternalStoragePath();
	if (!sgBase) {
		return;
	}
	char sgPath[1024];
	snprintf(sgPath, sizeof(sgPath), "%s/objects.txt", sgBase);
	FILE* sgFile = fopen(sgPath, "wb");
	if (!sgFile) {
		return;
	}
	fprintf(sgFile, "scene=%s\nuistate=%d\nobjetos com entidades:\n", Scene::CurrentScene, SG_UiStateNow());
	if (Scene::ObjectLists) {
		Scene::ObjectLists->WithAll([sgFile](Uint32, ObjectList* list) -> void {
			if (list != nullptr && list->EntityCount > 0 && list->ObjectName != nullptr) {
				fprintf(sgFile, "%s (%d)\n", list->ObjectName, (int)list->EntityCount);
			}
		});
	}
	fclose(sgFile);
#endif
}

// Grava files/uistate.txt ("0" = visiveis, "1" = cutscene, "2" = Sega/Starteam/title, "3" = fim de fase).
// So muda depois de ~0,4 s no mesmo estado, pra nao piscar.
static void SG_UpdateUiState() {
#ifdef ANDROID
	static Uint32 sgLastCheck = 0;
	static int sgWritten = -1;
	static int sgCandidate = 0;
	static Uint32 sgSince = 0;
	Uint32 sgNow = SDL_GetTicks();
	if (sgNow - sgLastCheck < 120) {
		return;
	}
	sgLastCheck = sgNow;
	int sgState = SG_UiStateNow();
	if (sgState != sgCandidate) {
		sgCandidate = sgState;
		sgSince = sgNow;
	}
	if (sgCandidate != sgWritten && (sgNow - sgSince >= 250 || sgWritten < 0)) {
		const char* sgBase = SDL_AndroidGetInternalStoragePath();
		if (sgBase) {
			char sgPath[1024];
			snprintf(sgPath, sizeof(sgPath), "%s/uistate.txt", sgBase);
			FILE* sgFile = fopen(sgPath, "wb");
			if (sgFile) {
				fputc('0' + sgCandidate, sgFile);
				fclose(sgFile);
				sgWritten = sgCandidate;
			}
		}
	}
#endif
}]=])
    string(REPLACE "${ANCHOR_H}" "${PATCH_H}" SCENE_SRC "${SCENE_SRC}")

    # Aviso de cutscene pro app (esconde os controles de toque)
    set(ANCHOR_R "void Scene::Render() {")
    string(FIND "${SCENE_SRC}" "${ANCHOR_R}" POS_R)
    if(POS_R EQUAL -1)
        message(WARNING "fitview_patch: Scene::Render nao encontrado; esconder controles na cutscene nao aplicado")
    else()
        string(REPLACE "${ANCHOR_R}" "void Scene::Render() {\n\tSG_UpdateUiState(); SG_HideEngineTouch(); SG_DumpObjects(); /*FITVIEW_PATCH_R*/" SCENE_SRC "${SCENE_SRC}")
    endif()

    # Modo 2: repete as colunas/linhas da borda da imagem onde sobraria barra preta
    set(ANCHOR_E "Graphics::SetUserShader(shader);")
    string(FIND "${SCENE_SRC}" "${ANCHOR_E}" POS_E)
    if(POS_E EQUAL -1)
        message(WARNING "fitview_patch: SetUserShader(shader) nao encontrado; extensao de borda nao aplicada")
    else()
        set(PATCH_E [=[Graphics::SetUserShader(shader);
				/*FITVIEW_PATCH_E*/
				if (viewCount == 1 && SG_ScreenMode() == 2) {
					float sgBarW = out_x, sgBarH = out_y;
					if (sgBarW > 0.5f) {
						Graphics::DrawTexture(currentView->DrawTarget, 0.0, 0.0, 1.0, currentView->Height,
							0.0, out_y + Graphics::PixelOffset, sgBarW + 1.0f, out_h + Graphics::PixelOffset);
						Graphics::DrawTexture(currentView->DrawTarget, currentView->Width - 1.0, 0.0, 1.0, currentView->Height,
							out_x + out_w - 1.0f, out_y + Graphics::PixelOffset, (win_w - out_x - out_w) + 1.0f, out_h + Graphics::PixelOffset);
					}
					if (sgBarH > 0.5f) {
						Graphics::DrawTexture(currentView->DrawTarget, 0.0, 0.0, currentView->Width, 1.0,
							out_x, 0.0 + Graphics::PixelOffset, out_w, sgBarH + 1.0f + Graphics::PixelOffset);
						Graphics::DrawTexture(currentView->DrawTarget, 0.0, currentView->Height - 1.0, currentView->Width, 1.0,
							out_x, out_y + out_h - 1.0f + Graphics::PixelOffset, out_w, (win_h - out_y - out_h) + 1.0f + Graphics::PixelOffset);
					}
				}
				/*FITVIEW_PATCH_E_END*/]=])
        string(REPLACE "${ANCHOR_E}" "${PATCH_E}" SCENE_SRC "${SCENE_SRC}")

        # Menu: depois do desenho principal da view, estica a ultima coluna do 16:9 sobre a parte cortada
        set(PATCH_S [=[
				/*FITVIEW_PATCH_S*/
				if (viewCount == 1 && SG_MenuStretchNow()) {
					float sgBX = currentView->Height * 16.0f / 9.0f;
					if (currentView->Width > sgBX + 1.0f) {
						float sgDX = out_x + out_w * (sgBX / currentView->Width);
						float sgDW = (out_x + out_w) - sgDX;
						Graphics::DrawTexture(currentView->DrawTarget, sgBX - 2.0f, 0.0, 1.0, currentView->Height,
							sgDX, out_y + Graphics::PixelOffset, sgDW, out_h + Graphics::PixelOffset);
					}
				}
]=])
        set(MARK_END "/*FITVIEW_PATCH_E_END*/")
        string(FIND "${SCENE_SRC}" "${MARK_END}" POS_MK)
        if(POS_MK EQUAL -1)
            message(WARNING "fitview_patch: marcador do bloco E nao encontrado; esticar menu nao aplicado")
        else()
            string(LENGTH "${MARK_END}" LEN_MK)
            math(EXPR TAIL_START "${POS_MK} + ${LEN_MK}")
            string(SUBSTRING "${SCENE_SRC}" 0 ${TAIL_START} S_HEAD)
            string(SUBSTRING "${SCENE_SRC}" ${TAIL_START} -1 S_TAIL)
            string(FIND "${S_TAIL}" "Graphics::DrawTexture(currentView->DrawTarget" POS_DT)
            if(POS_DT EQUAL -1)
                message(WARNING "fitview_patch: DrawTexture principal da view nao encontrado; esticar menu nao aplicado")
            else()
                string(SUBSTRING "${S_TAIL}" ${POS_DT} -1 S_CALL)
                string(FIND "${S_CALL}" ");" POS_STMT)
                math(EXPR CUT "${POS_DT} + ${POS_STMT} + 2")
                string(SUBSTRING "${S_TAIL}" 0 ${CUT} T_HEAD)
                string(SUBSTRING "${S_TAIL}" ${CUT} -1 T_REST)
                set(SCENE_SRC "${S_HEAD}${T_HEAD}\n${PATCH_S}${T_REST}")
                message(STATUS "fitview_patch: esticar menu aplicado")
            endif()
        endif()
    endif()

    # Render final: esticar a imagem do jogo na janela inteira
    set(ANCHOR_M "int aspectMode = (viewCount > 1) ? 3 : 1;")
    string(FIND "${SCENE_SRC}" "${ANCHOR_M}" POS_M)
    if(POS_M EQUAL -1)
        message(WARNING "fitview_patch: aspectMode nao encontrado; tela cheia (esticar) nao aplicada")
    else()
        set(PATCH_M "int aspectMode = (viewCount > 1) ? 3 : (SG_StretchScreen() ? 0 : 1); /*FITVIEW_PATCH_M*/")
        string(REPLACE "${ANCHOR_M}" "${PATCH_M}" SCENE_SRC "${SCENE_SRC}")
    endif()
    file(WRITE "${SCENE_CPP}" "${SCENE_SRC}")
    message(STATUS "fitview_patch: aplicado em Scene.cpp")
endif()

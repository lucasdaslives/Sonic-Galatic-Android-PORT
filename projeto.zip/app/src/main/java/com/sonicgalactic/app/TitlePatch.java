package com.sonicgalactic.app;

import android.content.Context;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.zip.CRC32;

/**
 * Troca a imagem "PRESS ANY BUTTON" da tela de titulo (Sprites/TitleScreen/StartButton.png, 120x8)
 * por "TOUCH TO START" direto dentro do Data.hatch que o app copiou (nao precisa de outro Data.hatch).
 *
 * Formato do .hatch (igual ao HatchVFS da engine): "HATCH" + versao(3) + qtd(uint16) + tabela de entradas de
 * 32 bytes {crc32 do nome (u32), offset (u64), tamanho gravado (u64), flag (u32; 2 = criptografado),
 * tamanho descompactado (u64)}. A imagem nova (sem compressao) e criptografada igual a engine faz e
 * ANEXADA no fim do arquivo; so entao a entrada da tabela passa a apontar pra ela (uma escrita de 28 bytes).
 * Se o jogo for fechado no meio, o arquivo continua valido. Rodar de novo nao faz nada (idempotente).
 */
final class TitlePatch {
    private static final String TAG = "SonicGalactic";
    private static final String ENTRY = "Sprites/TitleScreen/StartButton.png";
    private static final String ASSET = "title/StartButton.png";

    private TitlePatch() { }

    /** Aplica o patch; nunca lanca excecao (se algo falhar o jogo abre normal, so com o texto antigo). */
    static void apply(Context ctx, File hatch) {
        try {
            if (hatch == null || !hatch.isFile() || hatch.length() < 10) return;
            byte[] png = readAsset(ctx, ASSET);
            boolean changed = patch(hatch, ENTRY, png);
            Log.i(TAG, "TitlePatch: " + (changed ? "aplicado (Touch to start)" : "ja estava aplicado/entrada ausente"));
        } catch (Throwable t) {
            Log.w(TAG, "TitlePatch falhou: " + t);
        }
    }

    private static byte[] readAsset(Context ctx, String name) throws Exception {
        try (InputStream in = ctx.getAssets().open(name)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return o.toByteArray();
        }
    }

    /** @return true se gravou algo; false se ja estava igual (ou a entrada nao existe no .hatch). */
    static boolean patch(File hatch, String entryName, byte[] data) throws Exception {
        CRC32 c = new CRC32();
        c.update(entryName.getBytes("UTF-8"));
        final long hash = c.getValue();
        try (RandomAccessFile f = new RandomAccessFile(hatch, "rw")) {
            byte[] head = new byte[10];
            f.readFully(head);
            if (head[0] != 'H' || head[1] != 'A' || head[2] != 'T' || head[3] != 'C' || head[4] != 'H') return false;
            int count = (head[8] & 0xFF) | ((head[9] & 0xFF) << 8);
            byte[] toc = new byte[count * 32];
            f.readFully(toc);
            int idx = -1;
            for (int i = 0; i < count; i++) {
                if (le32(toc, i * 32) == hash) { idx = i; break; }
            }
            if (idx < 0) return false;
            int e = idx * 32;
            long off = le64(toc, e + 4), size = le64(toc, e + 12), flag = le32(toc, e + 20), csize = le64(toc, e + 24);

            // Ja esta com a imagem nova? (confere o conteudo decifrado)
            if (flag == 2 && size == csize && size == data.length && off >= 0 && off + size <= f.length()) {
                byte[] cur = new byte[(int) size];
                f.seek(off);
                f.readFully(cur);
                cryptoXor(cur, hash, true);
                if (Arrays.equals(cur, data)) return false;
            }

            byte[] out = data.clone();
            cryptoXor(out, hash, false); // flag 2 = criptografado
            long newOff = f.length();
            f.seek(newOff);
            f.write(out);
            f.getFD().sync();
            byte[] ent = new byte[28];
            put64(ent, 0, newOff);
            put64(ent, 8, out.length);
            put32(ent, 16, 2);
            put64(ent, 20, out.length); // tamanho == descompactado: sem compressao
            f.seek(10 + e + 4);
            f.write(ent);
            f.getFD().sync();
            return true;
        }
    }

    // Mesmo algoritmo de HatchVFS::CryptoXOR (engine)
    static void cryptoXor(byte[] data, long filenameHash, boolean decrypt) {
        int size = data.length;
        byte[] sz = new byte[8];
        put64(sz, 0, size);
        CRC32 sc = new CRC32();
        sc.update(sz);
        long sizeHash = sc.getValue();
        int[] keyA = new int[16], keyB = new int[16];
        for (int i = 0; i < 4; i++) {
            for (int k = 0; k < 4; k++) {
                keyA[i * 4 + k] = (int) ((filenameHash >> (8 * k)) & 0xFF);
                keyB[i * 4 + k] = (int) ((sizeHash >> (8 * k)) & 0xFF);
            }
        }
        boolean swap = false;
        int ia = 0, ib = 8;
        int xv = (size >> 2) & 0x7F;
        for (int x = 0; x < size; x++) {
            int t = data[x] & 0xFF;
            if (decrypt) t ^= xv ^ keyB[ib++]; else t ^= keyA[ia++];
            if (swap) t = ((t & 0x0F) << 4) | ((t & 0xF0) >> 4);
            if (!decrypt) t ^= xv ^ keyB[ib++]; else t ^= keyA[ia++];
            data[x] = (byte) t;
            if (ia <= 15) {
                if (ib > 12) { ib = 0; swap = !swap; }
            } else if (ib <= 8) {
                ia = 0; swap = !swap;
            } else {
                xv = (xv + 2) & 0x7F;
                if (swap) { swap = false; ia = xv % 7; ib = (xv % 12) + 2; }
                else { swap = true; ia = (xv % 12) + 3; ib = xv % 7; }
            }
        }
    }

    private static long le32(byte[] b, int o) {
        return (b[o] & 0xFFL) | ((b[o + 1] & 0xFFL) << 8) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 3] & 0xFFL) << 24);
    }
    private static long le64(byte[] b, int o) { return le32(b, o) | (le32(b, o + 4) << 32); }
    private static void put32(byte[] b, int o, long v) { for (int i = 0; i < 4; i++) b[o + i] = (byte) (v >> (8 * i)); }
    private static void put64(byte[] b, int o, long v) { for (int i = 0; i < 8; i++) b[o + i] = (byte) (v >> (8 * i)); }
}

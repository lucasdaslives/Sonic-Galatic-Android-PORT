package com.sonicgalactic.app;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import org.libsdl.app.SDLActivity;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Controles de toque: direcional + botoes A, S e Start (mesmo layout do site). */
public class TouchOverlay extends View {
    private static final int ROLE_DPAD = 1, ROLE_A = 2, ROLE_S = 3, ROLE_START = 4;
    // indices: 0 up, 1 down, 2 left, 3 right, 4 A, 5 S, 6 start
    private static final int[] KEYS = {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_ENTER };

    private final Paint paint = new Paint();
    private final Bitmap dpad, hlL, hlR, hlU, hlD, bA, bAh, bS, bSh, bStart, bStartH, bSkip, bBack;
    private final boolean[] sent = new boolean[7];
    private final boolean[] want = new boolean[7];
    private final Map<Integer, Integer> owner = new HashMap<>();
    private final float dp;
    private final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
    private static final long HOLD_MS = 500;
    // gestos fora dos controles: {startX, startY, startTime, anchorX, anchorY, moved(0/1), holdFired(0/1)}
    private final Map<Integer, float[]> gest = new HashMap<>();

    // esconder nas cutscenes: a engine grava files/uistate.txt ("1" = cutscene)
    private final java.io.File stateFile;
    private final boolean hideEnabled;
    // 0 = jogo/menu (botoes visiveis), 1 = cutscene (segurar na tela = Start),
    // 2 = Sega / Starteam / title (tocar na tela = A + Start), 3 = fim de fase (botoes somem)
    private int uiState;
    private boolean firstCutDone = false;
    private long cutStart = 0;
    private boolean hidden = false;
    private float alpha;                  // opacidade atual dos botoes (fade in / fade out)
    private long lastFrame = 0;
    // palavra SKIP (fonte do jogo) no topo durante a cutscene; segurar = pular
    private float skipAlpha = 0f;
    private long skipHoldStart = 0;
    private static final long FADE_IN_MS = 350, FADE_OUT_MS = 250;
    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (hideEnabled) {
                int v = -1;
                try (java.io.FileInputStream in = new java.io.FileInputStream(stateFile)) {
                    v = in.read();
                } catch (Exception ignored) { }
                if (v >= '0' && v <= '5') setUiState(v - '0'); // sem arquivo = mantem o estado atual
            }
            h.postDelayed(this, 40);
        }
    };

    private void setUiState(int ns) {
        if (ns == uiState) return;
        long nowMs = android.os.SystemClock.uptimeMillis();
        if (ns == 1) cutStart = nowMs;
        else if (uiState == 1 && nowMs - cutStart > 1500) firstCutDone = true; // a 1a cutscene do jogo acabou: SKIP nao aparece mais
        if (uiState == 3 && ns == 0) alpha = 1f; // act nova: botoes voltam na hora, sem fade
        uiState = ns;
        hidden = ns != 0 && ns != 4; // pausa (5) esconde tudo; nos menus (4) so fica o botao de voltar
        releaseAll(); // sair/entrar de cutscene: solta tudo e zera o "segurar"
        invalidate();
    }

    // geometria (px)
    private float s;
    private float dpX, dpY, dpSize;
    private float aCx, aCy, aR, sCx, sCy, sR;
    private final RectF startRect = new RectF();

    public TouchOverlay(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        paint.setFilterBitmap(false); paint.setAntiAlias(false); paint.setDither(false);
        paint.setAlpha(255);
        AssetManager am = c.getAssets();
        dpad = load(am, "dpad0"); hlL = load(am, "dpadhighlight6"); hlR = load(am, "dpadhighlight7");
        hlU = load(am, "dpadhighlight8"); hlD = load(am, "dpadhighlight9");
        bA = load(am, "dpad1"); bAh = load(am, "dpadhighlight1");
        bS = load(am, "dpad3"); bSh = load(am, "dpadhighlight3");
        bStart = load(am, "dpad5"); bStartH = load(am, "dpadhighlight5");
        bSkip = load(am, "skip");
        bBack = load(am, "back");
        setClickable(true);
        stateFile = new java.io.File(c.getFilesDir(), "uistate.txt");
        hideEnabled = c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("hideCutscene", true);
        uiState = hideEnabled ? 2 : 0; // o jogo abre na Sega: sem botoes, tocar = A/Start
        hidden = uiState != 0;
        alpha = hidden ? 0f : 1f;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        h.post(poll);
    }

    @Override
    protected void onDetachedFromWindow() {
        h.removeCallbacks(poll);
        super.onDetachedFromWindow();
    }

    private void releaseAll() {
        for (int i = 0; i < 7; i++) {
            want[i] = false;
            if (sent[i]) {
                sent[i] = false;
                SDLActivity.onNativeKeyUp(KEYS[i]);
            }
        }
        owner.clear();
        for (float[] g : gest.values()) {
            if (g[6] == 1) SDLActivity.onNativeKeyUp(KeyEvent.KEYCODE_ENTER);
        }
        gest.clear();
        skipHoldStart = 0;
    }

    private static Bitmap load(AssetManager am, String name) {
        try (InputStream in = am.open("touch/" + name + ".png")) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float f = getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("scale", 90) / 100f;
        s = Math.max(2f, Math.min(5f, Math.min(h / 110f, w / 230f))) * Math.max(1f, dp / 2.6f) * f * 1.4f;
        s = Math.min(s, w / 175f); // garante que direcional e botoes nao se encostem
        s = Math.max(2f, (float) Math.floor(s)); // escala inteira = pixel art nitido, sem borrar
        float m = 16 * dp;
        dpSize = 58 * s;
        dpX = m; dpY = h - m - dpSize;
        float actsW = 96 * s, actsH = 48 * s;
        float ax = w - m - actsW, ay = h - m - actsH;
        aCx = ax + 72 * s; aCy = ay + 24 * s; aR = 24 * s * 1.2f;
        sCx = ax + 22 * s; sCy = ay + 32 * s; sR = 16 * s * 1.4f;
        float sw = 14 * s * 2f, sh = 15 * s * 2f, pad = 12 * dp;
        float sx = w - 14 * dp - sw, sy = 10 * dp;
        startRect.set(sx - pad, sy - pad, sx + sw + pad, sy + sh + pad);
    }

    private void draw(Canvas c, Bitmap b, float x, float y, float w, float h) {
        if (b == null) return;
        c.drawBitmap(b, null, new RectF(Math.round(x), Math.round(y), Math.round(x) + Math.round(w), Math.round(y) + Math.round(h)), paint);
    }

    @Override
    protected void onDraw(Canvas c) {
        // fade in ao aparecer, fade out ao sumir (cutscene, Sega/title, fim de fase)
        long now = android.os.SystemClock.uptimeMillis();
        float target = (hidden || extHidden) ? 0f : 1f;
        float sTarget = (hideEnabled && uiState == 1 && !firstCutDone) ? 1f : 0f;
        float dt = lastFrame == 0 ? 0f : Math.min(64f, now - lastFrame);
        lastFrame = now;
        if (alpha < target) alpha = Math.min(target, alpha + dt / FADE_IN_MS);
        else if (alpha > target) alpha = Math.max(target, alpha - dt / FADE_OUT_MS);
        if (skipAlpha < sTarget) skipAlpha = Math.min(sTarget, skipAlpha + dt / FADE_IN_MS);
        else if (skipAlpha > sTarget) skipAlpha = Math.max(skipAlpha - dt / FADE_OUT_MS, sTarget);
        if (alpha != target || skipAlpha != sTarget || skipHoldStart != 0) postInvalidateOnAnimation(); else lastFrame = 0;
        if (alpha > 0f) {
            paint.setAlpha(Math.round(255 * alpha));
            if (uiState == 4) { drawBack(c, sCx, sCy, 16 * s, want[5]); paint.setAlpha(255); return; }
            draw(c, dpad, dpX, dpY, dpSize, dpSize);
            if (want[2]) draw(c, hlL, dpX, dpY + 22 * s, 29 * s, 14 * s);
            if (want[3]) draw(c, hlR, dpX + 29 * s, dpY + 22 * s, 29 * s, 14 * s);
            if (want[0]) draw(c, hlU, dpX + 23 * s, dpY, 12 * s, 29 * s);
            if (want[1]) draw(c, hlD, dpX + 23 * s, dpY + 29 * s, 12 * s, 29 * s);
            if (uiState == 4) drawBack(c, sCx, sCy, 16 * s, want[5]);
            else draw(c, want[5] ? bSh : bS, sCx - 16 * s, sCy - 16 * s, 32 * s, 32 * s);
            draw(c, want[4] ? bAh : bA, aCx - 24 * s, aCy - 24 * s, 48 * s, 48 * s);
            float sw = 14 * s * 2f, sh = 15 * s * 2f, pad = 12 * dp;
            draw(c, want[6] ? bStartH : bStart, startRect.left + pad, startRect.top + pad, sw, sh);
        }
        if (skipAlpha > 0f) drawSkip(c, now);
        paint.setAlpha(255);
    }

    // "SKIP" na fonte do Sonic Galactic, no topo da tela; ao segurar aparece uma barrinha enchendo
    private void drawSkip(Canvas c, long now) {
        if (bSkip == null) return;
        int k = Math.max(3, (int) s);
        float w = bSkip.getWidth() * k, h = bSkip.getHeight() * k;
        float x = (getWidth() - w) / 2f, y = 14 * dp;
        paint.setAlpha(Math.round(255 * skipAlpha));
        draw(c, bSkip, x, y, w, h);
        if (skipHoldStart != 0) {
            float p = Math.min(1f, (now - skipHoldStart) / (float) HOLD_MS);
            float by = y + h + 4 * dp, bh = Math.max(2f, k);
            bp.setStyle(Paint.Style.FILL);
            bp.setColor(0xFF484868);
            bp.setAlpha(Math.round(255 * skipAlpha));
            c.drawRect(x, by, x + w, by + bh, bp);
            bp.setColor(0xFFF0F0F0);
            bp.setAlpha(Math.round(255 * skipAlpha));
            c.drawRect(x, by, x + w * p, by + bh, bp);
        }
        paint.setAlpha(255);
    }

    // botao de voltar (no lugar do S) nos menus: quadrado com seta de "desfazer", no estilo do icone do jogo
    private final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.Path bpath = new android.graphics.Path();
    private void drawBack(Canvas c, float cx, float cy, float r, boolean pressed) {
        if (bBack != null) {
            // icone de voltar do jogo (assets/touch/back.png), escala inteira = pixel art nitido
            float k = Math.max(1f, Math.round(r * 2f / bBack.getWidth()));
            float sw = bBack.getWidth() * k, sh = bBack.getHeight() * k;
            paint.setAlpha(Math.round(255 * alpha));
            if (pressed) paint.setColorFilter(new android.graphics.LightingColorFilter(0xFFA0A0A0, 0));
            draw(c, bBack, cx - sw / 2f, cy - sh / 2f, sw, sh);
            paint.setColorFilter(null);
            paint.setAlpha(255);
            return;
        }
        int a = Math.round(255 * alpha);
        float h = r * 0.95f;
        RectF box = new RectF(cx - h, cy - h, cx + h, cy + h);
        bp.setStyle(Paint.Style.FILL);
        bp.setColor(pressed ? 0xFFB8D0A8 : 0xFF8CA67E);
        bp.setAlpha(a);
        c.drawRoundRect(box, h * 0.22f, h * 0.22f, bp);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(2f, h * 0.12f));
        bp.setColor(0xFF1E2A1E);
        bp.setAlpha(a);
        c.drawRoundRect(box, h * 0.22f, h * 0.22f, bp);
        float w = h * 0.16f;
        bp.setStrokeWidth(w);
        bp.setStrokeCap(Paint.Cap.SQUARE);
        RectF arc = new RectF(cx - h * 0.45f, cy - h * 0.2f, cx + h * 0.45f, cy + h * 0.7f);
        c.drawArc(arc, -90, 270, false, bp);
        bp.setStyle(Paint.Style.FILL);
        bpath.reset();
        float ax = cx, ay = cy - h * 0.2f;
        bpath.moveTo(ax - h * 0.05f, ay - h * 0.42f);
        bpath.lineTo(ax - h * 0.05f, ay + h * 0.42f);
        bpath.lineTo(ax - h * 0.62f, ay);
        bpath.close();
        c.drawPath(bpath, bp);
    }

    private int hit(float x, float y) {
        if (!hidden && uiState == 4) return Math.hypot(x - sCx, y - sCy) <= sR ? ROLE_S : 0; // menus: so o voltar
        if (hidden) return 0; // botoes escondidos: o toque vira gesto (segurar / tocar), tratado em startGesture
        float cx = dpX + dpSize / 2f, cy = dpY + dpSize / 2f;
        if (Math.hypot(x - cx, y - cy) <= dpSize / 2f * 1.8f) return ROLE_DPAD;
        double da = Math.hypot(x - aCx, y - aCy), ds = Math.hypot(x - sCx, y - sCy);
        boolean inA = da <= aR, inS = ds <= sR;
        if (inA && inS) return da / aR <= ds / sR ? ROLE_A : ROLE_S;
        if (inA) return ROLE_A;
        if (inS) return ROLE_S;
        if (startRect.contains(x, y)) return ROLE_START;
        return 0;
    }

    private void compute(MotionEvent e) {
        for (int i = 0; i < 7; i++) want[i] = false;
        int up = e.getActionMasked(), upIdx = e.getActionIndex();
        for (int i = 0; i < e.getPointerCount(); i++) {
            int id = e.getPointerId(i);
            boolean lifting = (up == MotionEvent.ACTION_UP || up == MotionEvent.ACTION_POINTER_UP
                    || up == MotionEvent.ACTION_CANCEL) && (up == MotionEvent.ACTION_CANCEL || i == upIdx);
            if (lifting) { owner.remove(id); endGesture(id, up == MotionEvent.ACTION_CANCEL); continue; }
            Integer role = owner.get(id);
            if (role == null) {
                boolean isDown = (up == MotionEvent.ACTION_DOWN || up == MotionEvent.ACTION_POINTER_DOWN) && i == upIdx;
                if (!isDown) continue;
                int r = hit(e.getX(i), e.getY(i));
                if (r == 0) { startGesture(id, e.getX(i), e.getY(i)); continue; }
                owner.put(id, r);
                role = r;
            }
            switch (role) {
                case ROLE_A: want[4] = true; break;
                case ROLE_S: want[5] = true; break;
                case ROLE_START: want[6] = true; break;
                case ROLE_DPAD: {
                    float r = dpSize / 2f;
                    float dx = e.getX(i) - (dpX + r), dy = e.getY(i) - (dpY + r);
                    float ax = Math.abs(dx), ay = Math.abs(dy);
                    if (Math.hypot(dx, dy) < r * 0.18f) break;
                    want[3] = dx > 0 && ax > r * 0.18f && ax > ay * 0.55f;
                    want[2] = dx < 0 && ax > r * 0.18f && ax > ay * 0.55f;
                    want[1] = dy > 0 && ay > r * 0.28f && ay > ax * 0.55f;
                    want[0] = dy < 0 && ay > r * 0.28f && ay > ax * 0.55f;
                    break;
                }
            }
        }
        if (up == MotionEvent.ACTION_CANCEL) owner.clear();
        if (up == MotionEvent.ACTION_MOVE) moveGestures(e);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        compute(e);
        for (int i = 0; i < 7; i++) {
            if (want[i] != sent[i]) {
                sent[i] = want[i];
                if (want[i]) SDLActivity.onNativeKeyDown(KEYS[i]);
                else SDLActivity.onNativeKeyUp(KEYS[i]);
            }
        }
        invalidate();
        return true;
    }

    // tocou na tela: os botoes voltam (se estavam escondidos por causa de controle/teclado)
    public void noteTouch(MotionEvent e) {
        if (extHidden) { extHidden = false; invalidate(); }
    }

    // apertou tecla/analogico de controle ou teclado: esconde os botoes de toque
    private volatile boolean extHidden = false;
    public void noteExternalInput() {
        if (extHidden) return;
        extHidden = true;
        h.post(() -> { releaseAll(); invalidate(); });
    }

    private void pulse(final int key, long ms) {
        SDLActivity.onNativeKeyDown(key);
        h.postDelayed(() -> SDLActivity.onNativeKeyUp(key), ms);
    }

    private void startGesture(final int id, float x, float y) {
        final float[] g = {x, y, android.os.SystemClock.uptimeMillis(), x, y, 0, 0, 0};
        gest.put(id, g);
        if (uiState == 4 && getWidth() > 0 && getHeight() > 0) {
            // Opcoes: dedo numa barrinha de volume = arrastar pra ajustar (esquerda/direita)
            int sl = 0;
            try { sl = GameActivity.nativeSliderAt(x / getWidth(), y / getHeight()); } catch (Throwable ignored) { }
            if (sl != 0) {
                g[7] = 1;
                if (sl == 2) { g[5] = 1; tapInGame(x, y); } // barra ainda nao selecionada: so seleciona
            }
        }
        if (uiState == 5) {
            // menu de pausa (inclui Yes/No): age no instante em que o dedo encosta, sem esperar soltar
            g[5] = 1;
            tapInGame(x, y);
        } else if (uiState == 2) {
            // Sega / Starteam / title: tocar em qualquer lugar = A + Start
            g[5] = 1;
            pulse(KeyEvent.KEYCODE_A, 90);
            pulse(KeyEvent.KEYCODE_ENTER, 90);
        } else if (uiState == 1) {
            // cutscene: segurar na tela = Start (so enquanto estiver na cutscene)
            if (skipHoldStart == 0 && !firstCutDone) skipHoldStart = android.os.SystemClock.uptimeMillis();
            h.postDelayed(() -> {
                if (uiState == 1 && gest.get(id) == g && g[6] == 0) {
                    g[6] = 1;
                    SDLActivity.onNativeKeyDown(KeyEvent.KEYCODE_ENTER);
                }
            }, HOLD_MS);
        }
    }

    private void moveGestures(MotionEvent e) {
        if (uiState == 1 || uiState == 2 || uiState == 3) return; // cutscene/splash: arrastar nao faz nada
        float step = 36 * dp;
        for (int i = 0; i < e.getPointerCount(); i++) {
            float[] g = gest.get(e.getPointerId(i));
            if (g == null || g[6] == 1) continue;
            if (g[7] == 1) {
                // barra de volume: cada ~9dp arrastados na horizontal = um passo Esquerda/Direita
                float sx = e.getX(i) - g[3];
                float stepPx = 9 * dp;
                int n = Math.min(8, (int) (Math.abs(sx) / stepPx));
                if (n > 0) {
                    g[5] = 1;
                    final int key = sx > 0 ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT;
                    for (int k = 0; k < n; k++) h.postDelayed(() -> pulse(key, 50), k * 70L);
                    g[3] += Math.signum(sx) * n * stepPx;
                }
                continue;
            }
            float dx = e.getX(i) - g[3], dy = e.getY(i) - g[4];
            if (Math.abs(dx) < step && Math.abs(dy) < step) continue;
            g[5] = 1;
            if (Math.abs(dy) >= Math.abs(dx)) pulse(dy > 0 ? KeyEvent.KEYCODE_DPAD_DOWN : KeyEvent.KEYCODE_DPAD_UP, 90);
            else pulse(dx > 0 ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT, 90);
            g[3] = e.getX(i); g[4] = e.getY(i);
        }
    }

    private void endGesture(int id, boolean cancel) {
        float[] g = gest.remove(id);
        if (gest.isEmpty()) skipHoldStart = 0;
        if (g == null) return;
        if (g[6] == 1) SDLActivity.onNativeKeyUp(KeyEvent.KEYCODE_ENTER);
        else if (!cancel && g[5] == 0 && uiState != 1 && uiState != 2) tapInGame(g[0], g[1]);
    }

    // toque simples no jogo/menu: se for num menu que a engine conhece, seleciona a opcao tocada (e confirma se ja estava selecionada);
    // se for outro lugar (ex.: dialogo ainda sem suporte), continua valendo o antigo "toque = botao A"
    private void tapInGame(float x, float y) {
        int r = -1;
        if (getWidth() > 0 && getHeight() > 0) {
            try {
                r = GameActivity.nativeTap(x / getWidth(), y / getHeight());
            } catch (Throwable ignored) { }
        }
        if (r == -1) {
            pulse(KeyEvent.KEYCODE_A, 90);
        } else if (r >= 3000) {
            h.postDelayed(() -> pulse(KeyEvent.KEYCODE_A, 90), 60); // selecao aplicada na proxima frame; A logo depois
        } else if (r >= 2000 && r < 3000) {
            // menu pediu teclas (ex.: Opcoes: tocar numa categoria = Cima/Baixo N vezes; slider = Esquerda/Direita)
            int a = r - 2000;
            final boolean confirm = a >= 100; // Yes/No: depois das teclas aperta A
            if (confirm) a -= 100;
            int k = a / 10, n = Math.max(1, Math.min(6, a % 10));
            if (confirm) h.postDelayed(() -> pulse(KeyEvent.KEYCODE_A, 90), n * 230L + 120);
            final int key = k == 0 ? KeyEvent.KEYCODE_DPAD_UP : k == 1 ? KeyEvent.KEYCODE_DPAD_DOWN
                    : k == 2 ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT;
            for (int i = 0; i < n; i++) h.postDelayed(() -> pulse(key, 90), i * 230L);
        } else if (r >= 1000) {
            pulse(KeyEvent.KEYCODE_A, 90); // tocou de novo na opcao ja selecionada: confirma
        }
        // 0..999: so selecionou a opcao; -2: tocou fora das opcoes
    }
}

package com.sonicgalactic.app;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import org.libsdl.app.SDLActivity;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Controles de toque: direcional + botoes A, S e Start (mesmo layout do site). */
public class TouchOverlay extends View {
    private static final int ROLE_DPAD = 1, ROLE_A = 2, ROLE_S = 3, ROLE_START = 4;
    // indices: 0 up, 1 down, 2 left, 3 right, 4 A, 5 S, 6 start
    private static final int[] KEYS = {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_ENTER };

    private final Paint paint = new Paint();
    private final Bitmap dpad, hlL, hlR, hlU, hlD, bA, bAh, bS, bSh, bStart, bStartH;
    private final boolean[] sent = new boolean[7];
    private final boolean[] want = new boolean[7];
    private final Map<Integer, Integer> owner = new HashMap<>();
    private final float dp;
    private final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
    private static final long HOLD_MS = 500;
    // gestos fora dos controles: {startX, startY, startTime, anchorX, anchorY, moved(0/1), holdFired(0/1)}
    private final Map<Integer, float[]> gest = new HashMap<>();

    // geometria (px)
    private float s;
    private float dpX, dpY, dpSize;
    private float aCx, aCy, aR, sCx, sCy, sR;
    private final RectF startRect = new RectF();

    public TouchOverlay(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        paint.setFilterBitmap(false); paint.setAntiAlias(false); paint.setDither(false);
        paint.setAlpha(255);
        AssetManager am = c.getAssets();
        dpad = load(am, "dpad0"); hlL = load(am, "dpadhighlight6"); hlR = load(am, "dpadhighlight7");
        hlU = load(am, "dpadhighlight8"); hlD = load(am, "dpadhighlight9");
        bA = load(am, "dpad1"); bAh = load(am, "dpadhighlight1");
        bS = load(am, "dpad3"); bSh = load(am, "dpadhighlight3");
        bStart = load(am, "dpad5"); bStartH = load(am, "dpadhighlight5");
        setClickable(true);
    }

    private static Bitmap load(AssetManager am, String name) {
        try (InputStream in = am.open("touch/" + name + ".png")) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float f = getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("scale", 100) / 100f;
        s = Math.max(2f, Math.min(5f, Math.min(h / 110f, w / 230f))) * Math.max(1f, dp / 2.6f) * f * 1.4f;
        s = Math.min(s, w / 175f); // garante que direcional e botoes nao se encostem
        s = Math.max(2f, (float) Math.floor(s)); // escala inteira = pixel art nitido, sem borrar
        float m = 16 * dp;
        dpSize = 58 * s;
        dpX = m; dpY = h - m - dpSize;
        float actsW = 96 * s, actsH = 48 * s;
        float ax = w - m - actsW, ay = h - m - actsH;
        aCx = ax + 72 * s; aCy = ay + 24 * s; aR = 24 * s * 1.2f;
        sCx = ax + 22 * s; sCy = ay + 32 * s; sR = 16 * s * 1.4f;
        float sw = 14 * s * 2f, sh = 15 * s * 2f, pad = 12 * dp;
        float sx = w - 14 * dp - sw, sy = 10 * dp;
        startRect.set(sx - pad, sy - pad, sx + sw + pad, sy + sh + pad);
    }

    private void draw(Canvas c, Bitmap b, float x, float y, float w, float h) {
        if (b == null) return;
        c.drawBitmap(b, null, new RectF(Math.round(x), Math.round(y), Math.round(x) + Math.round(w), Math.round(y) + Math.round(h)), paint);
    }

    @Override
    protected void onDraw(Canvas c) {
        draw(c, dpad, dpX, dpY, dpSize, dpSize);
        if (want[2]) draw(c, hlL, dpX, dpY + 22 * s, 29 * s, 14 * s);
        if (want[3]) draw(c, hlR, dpX + 29 * s, dpY + 22 * s, 29 * s, 14 * s);
        if (want[0]) draw(c, hlU, dpX + 23 * s, dpY, 12 * s, 29 * s);
        if (want[1]) draw(c, hlD, dpX + 23 * s, dpY + 29 * s, 12 * s, 29 * s);
        draw(c, want[5] ? bSh : bS, sCx - 16 * s, sCy - 16 * s, 32 * s, 32 * s);
        draw(c, want[4] ? bAh : bA, aCx - 24 * s, aCy - 24 * s, 48 * s, 48 * s);
        float sw = 14 * s * 2f, sh = 15 * s * 2f, pad = 12 * dp;
        draw(c, want[6] ? bStartH : bStart, startRect.left + pad, startRect.top + pad, sw, sh);
    }

    private int hit(float x, float y) {
        float cx = dpX + dpSize / 2f, cy = dpY + dpSize / 2f;
        if (Math.hypot(x - cx, y - cy) <= dpSize / 2f * 1.8f) return ROLE_DPAD;
        double da = Math.hypot(x - aCx, y - aCy), ds = Math.hypot(x - sCx, y - sCy);
        boolean inA = da <= aR, inS = ds <= sR;
        if (inA && inS) return da / aR <= ds / sR ? ROLE_A : ROLE_S;
        if (inA) return ROLE_A;
        if (inS) return ROLE_S;
        if (startRect.contains(x, y)) return ROLE_START;
        return 0;
    }

    private void compute(MotionEvent e) {
        for (int i = 0; i < 7; i++) want[i] = false;
        int up = e.getActionMasked(), upIdx = e.getActionIndex();
        for (int i = 0; i < e.getPointerCount(); i++) {
            int id = e.getPointerId(i);
            boolean lifting = (up == MotionEvent.ACTION_UP || up == MotionEvent.ACTION_POINTER_UP
                    || up == MotionEvent.ACTION_CANCEL) && (up == MotionEvent.ACTION_CANCEL || i == upIdx);
            if (lifting) { owner.remove(id); endGesture(id, up == MotionEvent.ACTION_CANCEL); continue; }
            Integer role = owner.get(id);
            if (role == null) {
                boolean isDown = (up == MotionEvent.ACTION_DOWN || up == MotionEvent.ACTION_POINTER_DOWN) && i == upIdx;
                if (!isDown) continue;
                int r = hit(e.getX(i), e.getY(i));
                if (r == 0) { startGesture(id, e.getX(i), e.getY(i)); continue; }
                owner.put(id, r);
                role = r;
            }
            switch (role) {
                case ROLE_A: want[4] = true; break;
                case ROLE_S: want[5] = true; break;
                case ROLE_START: want[6] = true; break;
                case ROLE_DPAD: {
                    float r = dpSize / 2f;
                    float dx = e.getX(i) - (dpX + r), dy = e.getY(i) - (dpY + r);
                    float ax = Math.abs(dx), ay = Math.abs(dy);
                    if (Math.hypot(dx, dy) < r * 0.18f) break;
                    want[3] = dx > 0 && ax > r * 0.18f && ax > ay * 0.55f;
                    want[2] = dx < 0 && ax > r * 0.18f && ax > ay * 0.55f;
                    want[1] = dy > 0 && ay > r * 0.28f && ay > ax * 0.55f;
                    want[0] = dy < 0 && ay > r * 0.28f && ay > ax * 0.55f;
                    break;
                }
            }
        }
        if (up == MotionEvent.ACTION_CANCEL) owner.clear();
        if (up == MotionEvent.ACTION_MOVE) moveGestures(e);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        compute(e);
        for (int i = 0; i < 7; i++) {
            if (want[i] != sent[i]) {
                sent[i] = want[i];
                if (want[i]) SDLActivity.onNativeKeyDown(KEYS[i]);
                else SDLActivity.onNativeKeyUp(KEYS[i]);
            }
        }
        invalidate();
        return true;
    }

    public void noteTouch(MotionEvent e) { }

    private void pulse(final int key, long ms) {
        SDLActivity.onNativeKeyDown(key);
        h.postDelayed(() -> SDLActivity.onNativeKeyUp(key), ms);
    }

    private void startGesture(final int id, float x, float y) {
        final float[] g = {x, y, android.os.SystemClock.uptimeMillis(), x, y, 0, 0};
        gest.put(id, g);
    }

    private void moveGestures(MotionEvent e) {
        float step = 36 * dp;
        for (int i = 0; i < e.getPointerCount(); i++) {
            float[] g = gest.get(e.getPointerId(i));
            if (g == null || g[6] == 1) continue;
            float dx = e.getX(i) - g[3], dy = e.getY(i) - g[4];
            if (Math.abs(dx) < step && Math.abs(dy) < step) continue;
            g[5] = 1;
            if (Math.abs(dy) >= Math.abs(dx)) pulse(dy > 0 ? KeyEvent.KEYCODE_DPAD_DOWN : KeyEvent.KEYCODE_DPAD_UP, 90);
            else pulse(dx > 0 ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT, 90);
            g[3] = e.getX(i); g[4] = e.getY(i);
        }
    }

    private void endGesture(int id, boolean cancel) {
        float[] g = gest.remove(id);
        if (g == null) return;
        if (g[6] == 1) SDLActivity.onNativeKeyUp(KeyEvent.KEYCODE_ENTER);
        else if (!cancel && g[5] == 0) pulse(KeyEvent.KEYCODE_A, 90); // toque = confirmar
    }
}

package com.sonicgalactic.app;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import org.libsdl.app.SDLActivity;

import java.io.File;

public class GameActivity extends SDLActivity {
    private TouchOverlay overlay;

    /** Toque direto no menu (patch touchmenu na engine): -1 = sem menu com toque, -2 = errou as opcoes, >= 0 = opcao tocada. */
    public static native int nativeTap(float nx, float ny);

    /** Linha de volume nas Opcoes: 0 = nao, 1 = barra selecionada, 2 = barra ainda nao selecionada. */
    public static native int nativeSliderAt(float nx, float ny);

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        if (overlay != null) overlay.noteTouch(ev);
        return super.dispatchTouchEvent(ev);
    }

    // controle ou teclado fisico: os botoes de toque somem (voltam ao tocar na tela)
    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent ev) {
        int k = ev.getKeyCode();
        if (overlay != null && ev.getAction() == android.view.KeyEvent.ACTION_DOWN && ev.getDeviceId() > 0
                && k != android.view.KeyEvent.KEYCODE_BACK && k != android.view.KeyEvent.KEYCODE_VOLUME_UP
                && k != android.view.KeyEvent.KEYCODE_VOLUME_DOWN && k != android.view.KeyEvent.KEYCODE_VOLUME_MUTE
                && k != android.view.KeyEvent.KEYCODE_POWER) {
            overlay.noteExternalInput();
        }
        return super.dispatchKeyEvent(ev);
    }

    @Override
    public boolean dispatchGenericMotionEvent(android.view.MotionEvent ev) {
        if (overlay != null && (ev.getSource() & android.view.InputDevice.SOURCE_JOYSTICK) != 0
                && ev.getActionMasked() == android.view.MotionEvent.ACTION_MOVE) {
            int[] axes = { android.view.MotionEvent.AXIS_X, android.view.MotionEvent.AXIS_Y,
                    android.view.MotionEvent.AXIS_Z, android.view.MotionEvent.AXIS_RZ,
                    android.view.MotionEvent.AXIS_HAT_X, android.view.MotionEvent.AXIS_HAT_Y };
            for (int ax : axes) {
                if (Math.abs(ev.getAxisValue(ax)) > 0.5f) { overlay.noteExternalInput(); break; }
            }
        }
        return super.dispatchGenericMotionEvent(ev);
    }

    @Override
    protected String[] getLibraries() {
        return new String[] { "SDL2", "main" };
    }

    @Override
    protected String[] getArguments() {
        // A engine carrega o jogo se o primeiro argumento terminar em .hatch
        File f = new File(getFilesDir(), SetupActivity.DATA_NAME);
        return new String[] { f.getAbsolutePath() };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Modo de tela lido pela engine (patch em fitview_patch.cmake): 0 = 16:9, 1 = esticar, 2 = repetir borda
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(new File(getFilesDir(), "screenmode.txt"))) {
            int mode = getSharedPreferences("cfg", MODE_PRIVATE).getInt("screenmode", 2); // 0 = 16:9, 1 = esticar, 2 = repetir borda
            o.write('0' + Math.max(0, Math.min(2, mode)));
        } catch (Exception ignored) { }
        // Renderizador: padrao = OpenGL ES (necessario pro 3D do Special/Bonus Stage); o arquivo
        // sdl2renderer.txt forca o renderizador antigo SDL2 (sem 3D), lido pela engine (gles_patch.cmake)
        File rf = new File(getFilesDir(), "sdl2renderer.txt");
        if (getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("sdl2renderer", false)) {
            try { rf.createNewFile(); } catch (Exception ignored) { }
        } else {
            rf.delete();
        }
        new File(getFilesDir(), "uistate.txt").delete(); // zera o aviso de cutscene da sessao anterior
        // Tela de titulo: troca "PRESS ANY BUTTON" por "TOUCH TO START" dentro do Data.hatch (so na 1a vez; depois nao faz nada)
        TitlePatch.apply(this, new File(getFilesDir(), SetupActivity.DATA_NAME));
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        boolean extra = true; // so o botao S
        if (mLayout != null && extra) {
            overlay = new TouchOverlay(this);
            mLayout.addView(overlay,
                    new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
}

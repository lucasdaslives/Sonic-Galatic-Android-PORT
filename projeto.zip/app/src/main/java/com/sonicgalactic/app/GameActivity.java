package com.sonicgalactic.app;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import org.libsdl.app.SDLActivity;

import java.io.File;

public class GameActivity extends SDLActivity {
    private TouchOverlay overlay;

    // ---- Tela 16:9 igual ao PC (modos 0 e 2) ----
    // A janela do jogo fica 16:9, centralizada; no modo 2 as laterais sao preenchidas
    // esticando as colunas da borda da imagem (ceu/chao continuam ate o fim da tela).
    private int fitMode = 2;
    private int barW = 0, lastLayoutW = 0, lastLayoutH = 0;
    private android.widget.ImageView barL, barR;
    private android.os.HandlerThread copyThread;
    private android.os.Handler copyHandler;
    private final android.os.Handler uiHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private volatile boolean copying = false, pumping = false;
    private int copyW, copyH;

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        if (overlay != null) overlay.noteTouch(ev);
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected String[] getLibraries() {
        return new String[] { "SDL2", "main" };
    }

    @Override
    protected String[] getArguments() {
        // A engine carrega o jogo se o primeiro argumento terminar em .hatch
        File f = new File(getFilesDir(), SetupActivity.DATA_NAME);
        return new String[] { f.getAbsolutePath() };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Modo de tela lido pela engine (patch em fitview_patch.cmake): 0 = 16:9, 1 = esticar, 2 = repetir borda
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(new File(getFilesDir(), "screenmode.txt"))) {
            int mode = getSharedPreferences("cfg", MODE_PRIVATE).getInt("screenmode", 2); // 0 = 16:9, 1 = esticar, 2 = repetir borda
            o.write('0' + Math.max(0, Math.min(2, mode)));
        } catch (Exception ignored) { }
        new File(getFilesDir(), "uistate.txt").delete(); // zera o aviso de cutscene da sessao anterior
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        fitMode = getSharedPreferences("cfg", MODE_PRIVATE).getInt("screenmode", 2);
        if (mLayout != null && mSurface != null && fitMode != 1) {
            setup16x9();
        }
        boolean extra = true; // so o botao S
        if (mLayout != null && extra) {
            overlay = new TouchOverlay(this);
            mLayout.addView(overlay,
                    new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    // ---------- 16:9 centralizado + laterais esticadas ----------
    private void setup16x9() {
        mLayout.setBackgroundColor(android.graphics.Color.BLACK);
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        if (fitMode == 2 && Build.VERSION.SDK_INT >= 26) {
            barL = newBar(true);
            barR = newBar(false);
            mLayout.addView(barL);
            mLayout.addView(barR);
            copyThread = new android.os.HandlerThread("barcopy");
            copyThread.start();
            copyHandler = new android.os.Handler(copyThread.getLooper());
        }
        // ja define o tamanho antes da 1a vez que a superficie e criada (a engine ja nasce em 16:9)
        applyFit(Math.max(dm.widthPixels, dm.heightPixels), Math.min(dm.widthPixels, dm.heightPixels));
        mLayout.addOnLayoutChangeListener((v, l, t, rr, b, ol, ot, orr, ob) -> {
            int w = rr - l, h = b - t;
            if (w > 0 && h > 0 && (w != lastLayoutW || h != lastLayoutH)) applyFit(w, h);
        });
    }

    private android.widget.ImageView newBar(boolean left) {
        android.widget.ImageView iv = new android.widget.ImageView(this);
        iv.setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
        iv.setBackgroundColor(android.graphics.Color.BLACK);
        iv.setVisibility(View.GONE);
        return iv;
    }

    private void placeSide(View v, int width, boolean left) {
        ViewGroup.LayoutParams lp;
        if (mLayout instanceof android.widget.RelativeLayout) {
            android.widget.RelativeLayout.LayoutParams rl =
                    new android.widget.RelativeLayout.LayoutParams(width, ViewGroup.LayoutParams.MATCH_PARENT);
            rl.addRule(left ? android.widget.RelativeLayout.ALIGN_PARENT_LEFT : android.widget.RelativeLayout.ALIGN_PARENT_RIGHT);
            lp = rl;
        } else {
            android.widget.FrameLayout.LayoutParams fl =
                    new android.widget.FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.MATCH_PARENT);
            fl.gravity = left ? android.view.Gravity.LEFT : android.view.Gravity.RIGHT;
            lp = fl;
        }
        v.setLayoutParams(lp);
    }

    private void applyFit(int W, int H) {
        lastLayoutW = W; lastLayoutH = H;
        int w = W, h = H;
        if ((long) W * 9 > (long) H * 16) w = H * 16 / 9; else h = W * 9 / 16;
        w &= ~1; h &= ~1;
        ViewGroup.LayoutParams old = mSurface.getLayoutParams();
        if (old == null || old.width != w || old.height != h) {
            ViewGroup.LayoutParams lp;
            if (mLayout instanceof android.widget.RelativeLayout) {
                android.widget.RelativeLayout.LayoutParams rl = new android.widget.RelativeLayout.LayoutParams(w, h);
                rl.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT);
                lp = rl;
            } else {
                android.widget.FrameLayout.LayoutParams fl = new android.widget.FrameLayout.LayoutParams(w, h);
                fl.gravity = android.view.Gravity.CENTER;
                lp = fl;
            }
            mSurface.setLayoutParams(lp);
        }
        barW = (W - w) / 2;
        if (barL != null && barR != null) {
            placeSide(barL, Math.max(barW, 1), true);
            placeSide(barR, Math.max(barW, 1), false);
            int vis = barW > 0 ? View.VISIBLE : View.GONE;
            barL.setVisibility(vis);
            barR.setVisibility(vis);
        }
    }

    // copia 2 colunas de pixels de cada borda da imagem do jogo e estica nas laterais (~30 fps)
    private final Runnable pump = new Runnable() {
        @Override public void run() {
            if (!pumping) return;
            if (!copying && barW > 0 && mSurface != null && mSurface.getHolder().getSurface().isValid()
                    && mSurface.getWidth() > 4 && mSurface.getHeight() > 4) {
                copying = true;
                copyW = mSurface.getWidth();
                copyH = mSurface.getHeight();
                grab(true);
            }
            uiHandler.postDelayed(this, 33);
        }
    };

    private void grab(final boolean left) {
        try {
            final android.graphics.Bitmap bm = android.graphics.Bitmap.createBitmap(2, copyH, android.graphics.Bitmap.Config.ARGB_8888);
            final android.graphics.Rect src = left ? new android.graphics.Rect(0, 0, 2, copyH)
                    : new android.graphics.Rect(copyW - 2, 0, copyW, copyH);
            android.view.PixelCopy.request(mSurface, src, bm, result -> {
                if (result == android.view.PixelCopy.SUCCESS) {
                    uiHandler.post(() -> (left ? barL : barR).setImageBitmap(bm));
                }
                if (left) grab(false); else copying = false;
            }, copyHandler);
        } catch (Throwable t) {
            copying = false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (barL != null && !pumping) { pumping = true; uiHandler.post(pump); }
    }

    @Override
    protected void onPause() {
        pumping = false;
        uiHandler.removeCallbacks(pump);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        pumping = false;
        if (copyThread != null) { copyThread.quitSafely(); copyThread = null; }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
}

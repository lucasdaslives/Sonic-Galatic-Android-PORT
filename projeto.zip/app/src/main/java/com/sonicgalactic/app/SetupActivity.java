package com.sonicgalactic.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;

public class SetupActivity extends Activity {
    public static final String DATA_NAME = "Data.hatch";
    private static final int REQ_PICK = 42;

    private TextView status;
    private Button play, pick;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(11, 15, 26));
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        TextView title = new TextView(this);
        title.setText("Sonic Galactic");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        status = new TextView(this);
        status.setTextColor(Color.rgb(190, 200, 225));
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, p / 2, 0, p / 2);
        root.addView(status);

        play = new Button(this);
        play.setText("Jogar");
        play.setOnClickListener(v -> {
            startActivity(new Intent(this, GameActivity.class));
        });
        root.addView(play);

        pick = new Button(this);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_PICK);
        });
        root.addView(pick);
        setContentView(root);
        refresh();
    }

    private File dataFile() { return new File(getFilesDir(), DATA_NAME); }

    private void refresh() {
        File f = dataFile();
        boolean ok = f.exists() && f.length() > 0;
        play.setVisibility(ok ? View.VISIBLE : View.GONE);
        pick.setEnabled(true);
        pick.setText(ok ? "Trocar o Data.hatch" : "Escolher o Data.hatch");
        status.setText(ok
                ? "Data.hatch pronto (" + (f.length() / (1024 * 1024)) + " MB)."
                : "Escolha o arquivo Data.hatch do jogo. Só precisa fazer isso uma vez.");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        play.setVisibility(View.GONE);
        pick.setEnabled(false);
        status.setText("Copiando... aguarde.");
        new Thread(() -> {
            String msg;
            File tmp = new File(getFilesDir(), DATA_NAME + ".tmp");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[1 << 20];
                long total = 0, last = 0;
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total - last > 8L * 1024 * 1024) {
                        last = total;
                        final long mb = total / (1024 * 1024);
                        runOnUiThread(() -> status.setText("Copiando... " + mb + " MB"));
                    }
                }
                out.flush();
                File dst = dataFile();
                if (dst.exists()) dst.delete();
                msg = tmp.renameTo(dst) ? null : "Erro ao salvar o arquivo.";
            } catch (Exception e) {
                tmp.delete();
                msg = "Erro ao copiar: " + e.getMessage();
            }
            final String m = msg;
            runOnUiThread(() -> {
                refresh();
                if (m != null) status.setText(m);
            });
        }).start();
    }
}

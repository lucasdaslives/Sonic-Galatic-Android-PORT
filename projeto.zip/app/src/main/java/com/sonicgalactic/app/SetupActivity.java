package com.sonicgalactic.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;

public class SetupActivity extends Activity {
    public static final String DATA_NAME = "Data.hatch";
    private static final int REQ_PICK = 42;
    private static final int DEFAULT_SCALE = 90; // tamanho padrao dos botoes de toque (%)

    private MenuView menu;
    private boolean busy = false;
    private String status = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("scale90", false)) { // 1a vez nessa versao: botoes em 90%
            prefs.edit().putInt("scale", DEFAULT_SCALE).putBoolean("scale90", true).apply();
        }
        menu = new MenuView(this);
        setContentView(menu);
        refresh();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private File dataFile() { return new File(getFilesDir(), DATA_NAME); }

    private boolean ready() {
        File f = dataFile();
        return f.exists() && f.length() > 0;
    }

    private void refresh() {
        if (!busy) status = "";
        if (menu != null) menu.invalidate();
    }

    private void play() {
        startActivity(new Intent(this, GameActivity.class));
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK);
    }

    /** Opcoes avancadas (segurar o logo): renderizador antigo + log. */
    private void advanced() {
        final SharedPreferences prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE);
        new AlertDialog.Builder(this)
                .setTitle("Avançado")
                .setMultiChoiceItems(new CharSequence[] {
                        "Renderizador antigo (SDL2): só se a tela ficar preta. Special/Bonus Stage ficam sem 3D" },
                        new boolean[] { prefs.getBoolean("sdl2renderer", false) },
                        (d, which, on) -> prefs.edit().putBoolean("sdl2renderer", on).apply())
                .setNeutralButton("Ver log", (d, w) -> mostrarLog())
                .setPositiveButton("OK", null)
                .show();
    }

    /** Tela inicial: arte de fundo (assets/menu.png) + dois botoes desenhados por cima. */
    private class MenuView extends View {
        private static final float IW = 2340f, IH = 1080f;
        // retangulos em coordenadas da imagem
        private final RectF b1 = new RectF(395, 565, 880, 790);
        private final RectF b2 = new RectF(1000, 565, 1440, 765);
        private final RectF cover2 = new RectF(985, 545, 1460, 800); // apaga o botao 2 quando nao usa
        private final RectF logo = new RectF(610, 25, 1450, 490);
        private final Bitmap bmp;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Handler hd = new Handler(Looper.getMainLooper());
        private float sc = 1f, ox = 0f, oy = 0f;
        private int down = 0; // 1 = botao 1, 2 = botao 2, 3 = logo
        private boolean longFired = false;
        private final Runnable longPress = () -> { longFired = true; advanced(); };

        MenuView(Context c) {
            super(c);
            Bitmap bm = null;
            try (InputStream in = c.getAssets().open("menu.png")) {
                bm = BitmapFactory.decodeStream(in);
            } catch (Exception ignored) { }
            bmp = bm;
            Typeface tf = Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
            fill.setTypeface(tf); fill.setTextAlign(Paint.Align.CENTER); fill.setColor(Color.WHITE);
            stroke.setTypeface(tf); stroke.setTextAlign(Paint.Align.CENTER);
            stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setColor(Color.rgb(40, 40, 40));
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            sc = Math.min(w / IW, h / IH);
            ox = (w - IW * sc) / 2f;
            oy = (h - IH * sc) / 2f;
        }

        private RectF map(RectF r) {
            return new RectF(ox + r.left * sc, oy + r.top * sc, ox + r.right * sc, oy + r.bottom * sc);
        }

        private void label(Canvas c, RectF imgRect, String text, boolean pressed) {
            RectF r = map(imgRect);
            float size = 62f * sc;
            fill.setTextSize(size);
            while (fill.measureText(text) > r.width() * 0.8f && size > 10f) {
                size -= 1f;
                fill.setTextSize(size);
            }
            stroke.setTextSize(size);
            stroke.setStrokeWidth(Math.max(2f, size * 0.12f));
            float y = r.centerY() - (fill.ascent() + fill.descent()) / 2f;
            int a = pressed ? 150 : 255;
            fill.setAlpha(a); stroke.setAlpha(a);
            c.drawText(text, r.centerX(), y, stroke);
            c.drawText(text, r.centerX(), y, fill);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawColor(Color.WHITE);
            if (bmp != null) {
                c.drawBitmap(bmp, null, new RectF(ox, oy, ox + IW * sc, oy + IH * sc), paint);
            }
            boolean ok = ready();
            boolean second = ok && !busy;
            if (!second) {
                Paint white = new Paint();
                white.setColor(Color.WHITE);
                c.drawRect(map(cover2), white);
            }
            String t1 = busy ? "Copiando..." : (ok ? "Jogar" : "Escolher data.hatch");
            label(c, b1, t1, down == 1);
            if (second) label(c, b2, "Trocar data.hatch", down == 2);
            if (status.length() > 0) {
                Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
                sp.setColor(Color.rgb(40, 40, 40));
                sp.setTextAlign(Paint.Align.CENTER);
                sp.setTextSize(40f * sc);
                c.drawText(status, ox + 1100f * sc, oy + 880f * sc, sp);
            }
        }

        private int hit(float x, float y) {
            float ix = (x - ox) / sc, iy = (y - oy) / sc;
            boolean second = ready() && !busy;
            if (b1.contains(ix, iy)) return 1;
            if (second && b2.contains(ix, iy)) return 2;
            if (logo.contains(ix, iy)) return 3;
            return 0;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down = hit(e.getX(), e.getY());
                    longFired = false;
                    if (down == 3) hd.postDelayed(longPress, 800);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (down != 0 && hit(e.getX(), e.getY()) != down) {
                        hd.removeCallbacks(longPress);
                        down = 0;
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP: {
                    hd.removeCallbacks(longPress);
                    int d = down;
                    down = 0;
                    invalidate();
                    if (d == 1 && !busy) {
                        if (ready()) play(); else pick();
                    } else if (d == 2 && !busy) {
                        pick();
                    }
                    return true;
                }
                case MotionEvent.ACTION_CANCEL:
                    hd.removeCallbacks(longPress);
                    down = 0;
                    invalidate();
                    return true;
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        busy = true;
        status = "Copiando... aguarde.";
        menu.invalidate();
        new Thread(() -> {
            String msg;
            File tmp = new File(getFilesDir(), DATA_NAME + ".tmp");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[1 << 20];
                long total = 0, last = 0;
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total - last > 8L * 1024 * 1024) {
                        last = total;
                        final long mb = total / (1024 * 1024);
                        runOnUiThread(() -> { status = "Copiando... " + mb + " MB"; menu.invalidate(); });
                    }
                }
                out.flush();
                File dst = dataFile();
                if (dst.exists()) dst.delete();
                msg = tmp.renameTo(dst) ? null : "Erro ao salvar o arquivo.";
            } catch (Exception e) {
                tmp.delete();
                msg = "Erro ao copiar: " + e.getMessage();
            }
            final String m = msg;
            runOnUiThread(() -> {
                busy = false;
                status = m != null ? m : "";
                menu.invalidate();
            });
        }).start();
    }
    private void mostrarLog() {
        Toast.makeText(this, "Lendo o log...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            final StringBuilder sbd = new StringBuilder();
            try {
                Process pr = Runtime.getRuntime().exec(new String[] {
                        "logcat", "-d", "-t", "800", "-v", "time", "-s",
                        "SonicGalactic:V", "SDL:V", "SDL/APP:V", "AndroidRuntime:E", "DEBUG:V" });
                BufferedReader r = new BufferedReader(new InputStreamReader(pr.getInputStream()));
                ArrayList<String> linhas = new ArrayList<>();
                String l;
                while ((l = r.readLine()) != null) linhas.add(l);
                int ini = Math.max(0, linhas.size() - 250);
                for (int i = ini; i < linhas.size(); i++) sbd.append(linhas.get(i)).append('\n');
            } catch (Exception e) {
                sbd.append("Erro ao ler o log: ").append(e.getMessage());
            }
            if (sbd.length() == 0) sbd.append("(log vazio - jogue ate dar o erro e abra aqui de novo)");
            final String txt = sbd.toString();
            runOnUiThread(() -> {
                TextView tv = new TextView(this);
                tv.setText(txt);
                tv.setTextSize(10);
                tv.setTextIsSelectable(true);
                tv.setPadding(24, 24, 24, 24);
                ScrollView s = new ScrollView(this);
                s.addView(tv);
                new AlertDialog.Builder(this)
                        .setTitle("Log do jogo")
                        .setView(s)
                        .setPositiveButton("Copiar", (d, w) -> {
                            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            cm.setPrimaryClip(ClipData.newPlainText("log", txt));
                            Toast.makeText(this, "Copiado!", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Fechar", null)
                        .show();
            });
        }).start();
    }
}

package com.sonicgalactic.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.CheckBox;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;

public class SetupActivity extends Activity {
    public static final String DATA_NAME = "Data.hatch";
    private static final int REQ_PICK = 42;

    private TextView status;
    private Button play, pick;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(11, 15, 26));
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        TextView title = new TextView(this);
        title.setText("Sonic Galactic");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        status = new TextView(this);
        status.setTextColor(Color.rgb(190, 200, 225));
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, p / 2, 0, p / 2);
        root.addView(status);

        play = new Button(this);
        play.setText("Jogar");
        play.setOnClickListener(v -> {
            startActivity(new Intent(this, GameActivity.class));
        });
        root.addView(play);

        pick = new Button(this);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_PICK);
        });
        root.addView(pick);

        final SharedPreferences prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE);
        final TextView sizeLabel = new TextView(this);
        sizeLabel.setTextColor(Color.rgb(190, 200, 225));
        sizeLabel.setGravity(Gravity.CENTER);
        sizeLabel.setPadding(0, p / 2, 0, 0);
        root.addView(sizeLabel);
        SeekBar sb = new SeekBar(this);
        sb.setMax(110); // 50% .. 160%
        sb.setProgress(prefs.getInt("scale", 100) - 50);
        sizeLabel.setText("Tamanho dos botoes: " + prefs.getInt("scale", 100) + "%");
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                sizeLabel.setText("Tamanho dos botoes: " + (v + 50) + "%");
                prefs.edit().putInt("scale", v + 50).apply();
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        root.addView(sb);

        TextView modeLabel = new TextView(this);
        modeLabel.setText("Tela do jogo:");
        modeLabel.setTextColor(Color.rgb(190, 200, 225));
        modeLabel.setPadding(0, p / 2, 0, 0);
        root.addView(modeLabel);
        final String[] modeNames = {
                "Manter proporção 16:9 (barras pretas)",
                "Esticar (preenche tudo, deforma a imagem)",
                "Preencher repetindo a borda da imagem (sem deformar)" };
        android.widget.RadioGroup rg = new android.widget.RadioGroup(this);
        for (int i = 0; i < 3; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setId(1000 + i);
            rb.setText(modeNames[i]);
            rb.setTextColor(Color.rgb(190, 200, 225));
            rg.addView(rb);
        }
        rg.check(1000 + prefs.getInt("screenmode", 2));
        rg.setOnCheckedChangeListener((g, id) -> prefs.edit().putInt("screenmode", id - 1000).apply());
        root.addView(rg);

        CheckBox hc = new CheckBox(this);
        hc.setText("Esconder os botões na tela durante as cutscenes");
        hc.setTextColor(Color.rgb(190, 200, 225));
        hc.setChecked(prefs.getBoolean("hideCutscene", true));
        hc.setOnCheckedChangeListener((cb, on) -> prefs.edit().putBoolean("hideCutscene", on).apply());
        root.addView(hc);

        CheckBox ov = new CheckBox(this);
        ov.setText("Usar controles de toque do app (so se os do jogo nao funcionarem)");
        ov.setTextColor(Color.rgb(190, 200, 225));
        ov.setChecked(prefs.getBoolean("overlay", false));
        ov.setOnCheckedChangeListener((cb, on) -> prefs.edit().putBoolean("overlay", on).apply());
        root.addView(ov);

        Button log = new Button(this);
        log.setText("Ver log (erros do jogo)");
        log.setOnClickListener(v -> mostrarLog());
        root.addView(log);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);
        refresh();
    }

    private File dataFile() { return new File(getFilesDir(), DATA_NAME); }

    private void refresh() {
        File f = dataFile();
        boolean ok = f.exists() && f.length() > 0;
        play.setVisibility(ok ? View.VISIBLE : View.GONE);
        pick.setEnabled(true);
        pick.setText(ok ? "Trocar o Data.hatch" : "Escolher o Data.hatch");
        status.setText(ok
                ? "Data.hatch pronto (" + (f.length() / (1024 * 1024)) + " MB)."
                : "Escolha o arquivo Data.hatch do jogo. Só precisa fazer isso uma vez.");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        play.setVisibility(View.GONE);
        pick.setEnabled(false);
        status.setText("Copiando... aguarde.");
        new Thread(() -> {
            String msg;
            File tmp = new File(getFilesDir(), DATA_NAME + ".tmp");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[1 << 20];
                long total = 0, last = 0;
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total - last > 8L * 1024 * 1024) {
                        last = total;
                        final long mb = total / (1024 * 1024);
                        runOnUiThread(() -> status.setText("Copiando... " + mb + " MB"));
                    }
                }
                out.flush();
                File dst = dataFile();
                if (dst.exists()) dst.delete();
                msg = tmp.renameTo(dst) ? null : "Erro ao salvar o arquivo.";
            } catch (Exception e) {
                tmp.delete();
                msg = "Erro ao copiar: " + e.getMessage();
            }
            final String m = msg;
            runOnUiThread(() -> {
                refresh();
                if (m != null) status.setText(m);
            });
        }).start();
    }
    private void mostrarLog() {
        Toast.makeText(this, "Lendo o log...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            final StringBuilder sbd = new StringBuilder();
            try {
                Process pr = Runtime.getRuntime().exec(new String[] {
                        "logcat", "-d", "-t", "800", "-v", "time", "-s",
                        "SonicGalactic:V", "SDL:V", "SDL/APP:V", "AndroidRuntime:E", "DEBUG:V" });
                BufferedReader r = new BufferedReader(new InputStreamReader(pr.getInputStream()));
                ArrayList<String> linhas = new ArrayList<>();
                String l;
                while ((l = r.readLine()) != null) linhas.add(l);
                int ini = Math.max(0, linhas.size() - 250);
                for (int i = ini; i < linhas.size(); i++) sbd.append(linhas.get(i)).append('\n');
            } catch (Exception e) {
                sbd.append("Erro ao ler o log: ").append(e.getMessage());
            }
            if (sbd.length() == 0) sbd.append("(log vazio - jogue ate dar o erro e abra aqui de novo)");
            final String txt = sbd.toString();
            runOnUiThread(() -> {
                TextView tv = new TextView(this);
                tv.setText(txt);
                tv.setTextSize(10);
                tv.setTextIsSelectable(true);
                tv.setPadding(24, 24, 24, 24);
                ScrollView s = new ScrollView(this);
                s.addView(tv);
                new AlertDialog.Builder(this)
                        .setTitle("Log do jogo")
                        .setView(s)
                        .setPositiveButton("Copiar", (d, w) -> {
                            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            cm.setPrimaryClip(ClipData.newPlainText("log", txt));
                            Toast.makeText(this, "Copiado!", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Fechar", null)
                        .show();
            });
        }).start();
    }
}

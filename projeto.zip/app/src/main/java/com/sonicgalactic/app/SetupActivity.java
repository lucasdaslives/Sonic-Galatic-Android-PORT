package com.sonicgalactic.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Random;

public class SetupActivity extends Activity {
    public static final String DATA_NAME = "Data.hatch";
    private static final int REQ_PICK = 42;
    private static final int DEFAULT_SCALE = 90; // tamanho padrao dos botoes de toque (%)

    private MenuView menu;
    private boolean busy = false;
    private String status = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("scale90", false)) { // 1a vez nessa versao: botoes em 90%
            prefs.edit().putInt("scale", DEFAULT_SCALE).putBoolean("scale90", true).apply();
        }
        menu = new MenuView(this);
        setContentView(menu);
        refresh();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private File dataFile() { return new File(getFilesDir(), DATA_NAME); }

    private boolean ready() {
        File f = dataFile();
        return f.exists() && f.length() > 0;
    }

    private void refresh() {
        if (!busy) status = "";
        if (menu != null) menu.relayout();
    }

    private void play() {
        startActivity(new Intent(this, GameActivity.class));
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK);
    }

    /** Opcoes avancadas (segurar o logo): renderizador antigo + log. */
    private void advanced() {
        final SharedPreferences prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE);
        new AlertDialog.Builder(this)
                .setTitle("Avançado")
                .setMultiChoiceItems(new CharSequence[] {
                        "Renderizador antigo (SDL2): só se a tela ficar preta. Special/Bonus Stage ficam sem 3D" },
                        new boolean[] { prefs.getBoolean("sdl2renderer", false) },
                        (d, which, on) -> prefs.edit().putBoolean("sdl2renderer", on).apply())
                .setNeutralButton("Ver log", (d, w) -> mostrarLog())
                .setPositiveButton("OK", null)
                .show();
    }

    /** Tela inicial: degrade + estrelas desenhados por codigo, Sonic/Tails/Fang nos cantos, logo no topo e botoes redondos. */
    private class MenuView extends View {
        private final Bitmap sonic, tails, fang, logo;
        private final Paint bmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Handler hd = new Handler(Looper.getMainLooper());
        private final RectF rSonic = new RectF(), rTails = new RectF(), rFang = new RectF(), rLogo = new RectF();
        private final RectF rB1 = new RectF(), rB2 = new RectF();
        private final float[] stX = new float[70], stY = new float[70], stS = new float[70];
        private final Path star = new Path();
        private float u = 1f, oy = 0f, bh = 1f;
        private int down = 0; // 1 = botao 1, 2 = botao 2, 3 = logo
        private boolean longFired = false;
        private final Runnable longPress = () -> { longFired = true; advanced(); };

        MenuView(Context c) {
            super(c);
            sonic = load(c, "sonic"); tails = load(c, "tails"); fang = load(c, "fang"); logo = load(c, "logo");
            Typeface tf = Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
            fill.setTypeface(tf); fill.setTextAlign(Paint.Align.CENTER);
            stroke.setTypeface(tf); stroke.setTextAlign(Paint.Align.CENTER);
            stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeJoin(Paint.Join.ROUND);
            Random r = new Random(7);
            for (int i = 0; i < stX.length; i++) { stX[i] = r.nextFloat(); stY[i] = r.nextFloat(); stS[i] = 0.4f + r.nextFloat() * 0.9f; }
        }

        private Bitmap load(Context c, String n) {
            try (InputStream in = c.getAssets().open("menu/" + n + ".png")) {
                return BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                return null;
            }
        }

        private void place(RectF out, Bitmap b, float h, float anchorX, float anchorY, boolean right, boolean bottom) {
            float w = b == null ? h : h * b.getWidth() / b.getHeight();
            float l = right ? anchorX - w : anchorX;
            float t = bottom ? anchorY - h : anchorY;
            out.set(l, t, l + w, t + h);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            u = Math.min(h, w / 2f);              // unidade de layout (telas mais "quadradas" encolhem o conteudo)
            oy = (h - u) / 2f;                    // centraliza logo/botoes na vertical
            place(rSonic, sonic, 0.62f * u, 0, h, false, true);
            place(rFang, fang, 0.64f * u, w, h, true, true);
            place(rTails, tails, 0.38f * u, w, 0, true, false);
            place(rLogo, logo, 0.40f * u, 0, oy + 0.03f * u, false, false);
            rLogo.offset(w / 2f - rLogo.width() / 2f, 0);
            bh = 0.15f * u;
            float bw = 0.46f * u, gap = 0.04f * u, cy = oy + 0.70f * u;
            if (ready() && !busy) {
                float x0 = w / 2f - bw - gap / 2f;
                rB1.set(x0, cy - bh / 2f, x0 + bw, cy + bh / 2f);
                rB2.set(x0 + bw + gap, cy - bh / 2f, x0 + 2 * bw + gap, cy + bh / 2f);
            } else {
                rB1.set(w / 2f - bw / 2f - 0.05f * u, cy - bh / 2f, w / 2f + bw / 2f + 0.05f * u, cy + bh / 2f);
                rB2.setEmpty();
            }
        }

        private void sparkle(Canvas c, float x, float y, float r) {
            star.reset();
            star.moveTo(x, y - r);
            star.quadTo(x, y, x + r, y);
            star.quadTo(x, y, x, y + r);
            star.quadTo(x, y, x - r, y);
            star.quadTo(x, y, x, y - r);
            c.drawPath(star, p);
        }

        private void button(Canvas c, RectF r, String text, boolean primary, boolean pressed) {
            float k = pressed ? 0.96f : 1f;
            float cx = r.centerX(), cy = r.centerY();
            float w = r.width() * k, h = r.height() * k;
            RectF b = new RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
            float rad = h / 2f, line = Math.max(3f, h * 0.06f);
            // sombra
            p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(Color.argb(70, 20, 10, 80));
            c.drawRoundRect(new RectF(b.left, b.top + h * 0.09f, b.right, b.bottom + h * 0.09f), rad, rad, p);
            // corpo (degrade igual ao da logo: amarelo / roxo)
            int top = primary ? Color.rgb(255, 224, 96) : Color.rgb(176, 140, 240);
            int bot = primary ? Color.rgb(255, 170, 20) : Color.rgb(106, 72, 196);
            if (pressed) { top = darker(top); bot = darker(bot); }
            p.setShader(new LinearGradient(0, b.top, 0, b.bottom, top, bot, Shader.TileMode.CLAMP));
            c.drawRoundRect(b, rad, rad, p);
            p.setShader(null);
            // brilho em cima
            p.setColor(Color.argb(pressed ? 40 : 80, 255, 255, 255));
            c.drawRoundRect(new RectF(b.left + h * 0.18f, b.top + h * 0.08f, b.right - h * 0.18f, b.top + h * 0.40f), h * 0.16f, h * 0.16f, p);
            // contorno azul-marinho da logo
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(line); p.setColor(Color.rgb(30, 22, 120));
            c.drawRoundRect(b, rad, rad, p);
            p.setStyle(Paint.Style.FILL);
            // texto
            float size = h * 0.42f;
            fill.setTextSize(size);
            while (fill.measureText(text) > b.width() * 0.84f && size > 10f) { size -= 1f; fill.setTextSize(size); }
            stroke.setTextSize(size); stroke.setStrokeWidth(Math.max(2f, size * 0.14f));
            fill.setColor(primary ? Color.rgb(30, 22, 120) : Color.WHITE);
            stroke.setColor(primary ? Color.argb(0, 0, 0, 0) : Color.rgb(30, 22, 120));
            float y = b.centerY() - (fill.ascent() + fill.descent()) / 2f;
            if (!primary) c.drawText(text, b.centerX(), y, stroke);
            c.drawText(text, b.centerX(), y, fill);
        }

        private int darker(int col) {
            return Color.rgb((int) (Color.red(col) * 0.85f), (int) (Color.green(col) * 0.85f), (int) (Color.blue(col) * 0.85f));
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            // fundo: ceu azul -> lilas
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, 0, 0, h,
                    new int[] { Color.rgb(116, 196, 255), Color.rgb(170, 178, 255), Color.rgb(226, 190, 255) },
                    new float[] { 0f, 0.6f, 1f }, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            // estrelinhas
            p.setColor(Color.argb(210, 255, 255, 255));
            for (int i = 0; i < stX.length; i++) sparkle(c, stX[i] * w, stY[i] * h, stS[i] * 0.018f * u);
            // "swoosh" azul atras do Fang e roxo atras do Sonic
            p.setColor(Color.rgb(30, 90, 255));
            c.drawOval(new RectF(w - 0.95f * u, h - 0.42f * u, w + 0.55f * u, h + 0.75f * u), p);
            p.setColor(Color.rgb(70, 150, 255));
            c.drawOval(new RectF(w - 0.80f * u, h - 0.30f * u, w + 0.60f * u, h + 0.75f * u), p);
            p.setColor(Color.argb(150, 120, 80, 220));
            c.drawOval(new RectF(-0.60f * u, h - 0.26f * u, 0.55f * u, h + 0.60f * u), p);
            // personagens e logo
            if (tails != null) c.drawBitmap(tails, null, rTails, bmpPaint);
            if (sonic != null) c.drawBitmap(sonic, null, rSonic, bmpPaint);
            if (fang != null) c.drawBitmap(fang, null, rFang, bmpPaint);
            if (logo != null) c.drawBitmap(logo, null, rLogo, bmpPaint);
            // botoes
            boolean ok = ready();
            String t1 = busy ? "Copiando..." : (ok ? "Jogar" : "Escolher data.hatch");
            button(c, rB1, t1, true, down == 1);
            if (ok && !busy) button(c, rB2, "Trocar data.hatch", false, down == 2);
            if (status.length() > 0) {
                p.setColor(Color.rgb(30, 22, 120));
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                p.setTextSize(0.04f * u);
                c.drawText(status, w / 2f, rB1.bottom + 0.09f * u, p);
            }
        }

        private int hit(float x, float y) {
            if (rB1.contains(x, y)) return 1;
            if (!rB2.isEmpty() && rB2.contains(x, y)) return 2;
            if (rLogo.contains(x, y)) return 3;
            return 0;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down = hit(e.getX(), e.getY());
                    longFired = false;
                    if (down == 3) hd.postDelayed(longPress, 800);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (down != 0 && hit(e.getX(), e.getY()) != down) {
                        hd.removeCallbacks(longPress);
                        down = 0;
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP: {
                    hd.removeCallbacks(longPress);
                    int d = down;
                    down = 0;
                    invalidate();
                    if (d == 1 && !busy) {
                        if (ready()) play(); else pick();
                    } else if (d == 2 && !busy) {
                        pick();
                    }
                    return true;
                }
                case MotionEvent.ACTION_CANCEL:
                    hd.removeCallbacks(longPress);
                    down = 0;
                    invalidate();
                    return true;
            }
            return true;
        }

        /** Recalcula os botoes (1 ou 2) quando o estado muda (data.hatch escolhido / copiando). */
        void relayout() { onSizeChanged(getWidth(), getHeight(), 0, 0); invalidate(); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        busy = true;
        status = "Copiando... aguarde.";
        menu.relayout();
        new Thread(() -> {
            String msg;
            File tmp = new File(getFilesDir(), DATA_NAME + ".tmp");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[1 << 20];
                long total = 0, last = 0;
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total - last > 8L * 1024 * 1024) {
                        last = total;
                        final long mb = total / (1024 * 1024);
                        runOnUiThread(() -> { status = "Copiando... " + mb + " MB"; menu.invalidate(); });
                    }
                }
                out.flush();
                File dst = dataFile();
                if (dst.exists()) dst.delete();
                msg = tmp.renameTo(dst) ? null : "Erro ao salvar o arquivo.";
            } catch (Exception e) {
                tmp.delete();
                msg = "Erro ao copiar: " + e.getMessage();
            }
            final String m = msg;
            runOnUiThread(() -> {
                busy = false;
                status = m != null ? m : "";
                menu.relayout();
            });
        }).start();
    }
    private void mostrarLog() {
        Toast.makeText(this, "Lendo o log...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            final StringBuilder sbd = new StringBuilder();
            try {
                Process pr = Runtime.getRuntime().exec(new String[] {
                        "logcat", "-d", "-t", "800", "-v", "time", "-s",
                        "SonicGalactic:V", "SDL:V", "SDL/APP:V", "AndroidRuntime:E", "DEBUG:V" });
                BufferedReader r = new BufferedReader(new InputStreamReader(pr.getInputStream()));
                ArrayList<String> linhas = new ArrayList<>();
                String l;
                while ((l = r.readLine()) != null) linhas.add(l);
                int ini = Math.max(0, linhas.size() - 250);
                for (int i = ini; i < linhas.size(); i++) sbd.append(linhas.get(i)).append('\n');
            } catch (Exception e) {
                sbd.append("Erro ao ler o log: ").append(e.getMessage());
            }
            if (sbd.length() == 0) sbd.append("(log vazio - jogue ate dar o erro e abra aqui de novo)");
            final String txt = sbd.toString();
            runOnUiThread(() -> {
                TextView tv = new TextView(this);
                tv.setText(txt);
                tv.setTextSize(10);
                tv.setTextIsSelectable(true);
                tv.setPadding(24, 24, 24, 24);
                ScrollView s = new ScrollView(this);
                s.addView(tv);
                new AlertDialog.Builder(this)
                        .setTitle("Log do jogo")
                        .setView(s)
                        .setPositiveButton("Copiar", (d, w) -> {
                            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            cm.setPrimaryClip(ClipData.newPlainText("log", txt));
                            Toast.makeText(this, "Copiado!", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Fechar", null)
                        .show();
            });
        }).start();
    }
}
